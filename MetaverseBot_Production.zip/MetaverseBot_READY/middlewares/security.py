"""
Advanced security middleware with rate limiting, anti-spam, and fraud detection
"""

from datetime import datetime, timedelta
from typing import Optional, Callable, Dict, Any
from functools import wraps
from telegram import Update
from telegram.ext import ContextTypes
from telegram.error import TelegramError
from config import settings
from services.cache import cache
from loguru import logger
import hashlib
import time


class SecurityManager:
    """Advanced security management"""
    
    def __init__(self):
        self.failed_attempts = {}
        self.suspicious_users = set()
        self.ip_blacklist = set()
        self.blocked_patterns = [
            r'http[s]?://',  # URLs
            r'@\w+bot',  # Bot mentions
            # Add more patterns
        ]
    
    # ═══════════════════════════════════════════════════════
    # Channel & Group Verification
    # ═══════════════════════════════════════════════════════
    
    async def check_channel_membership(
        self, 
        context: ContextTypes.DEFAULT_TYPE, 
        user_id: int
    ) -> bool:
        """Check if user is member of required channel"""
        
        # Check cache first
        cache_key = f"member:{user_id}"
        cached = await cache.get(cache_key)
        if cached is not None:
            return cached
        
        try:
            member = await context.bot.get_chat_member(
                chat_id=settings.REQUIRED_CHANNEL,
                user_id=user_id
            )
            
            is_member = member.status in ["member", "administrator", "creator"]
            
            # Cache result for 5 minutes
            await cache.set(cache_key, is_member, ttl=300)
            
            if not is_member:
                await self._log_failed_join(user_id)
            
            return is_member
        
        except TelegramError as e:
            logger.error(f"Error checking membership for {user_id}: {e}")
            return False
    
    async def _log_failed_join(self, user_id: int):
        """Log failed join attempt"""
        key = f"failed_join:{user_id}"
        count = await cache.incr(key)
        
        if count == 1:
            await cache.expire(key, 300)  # 5 minutes window
        
        if count > 5:
            await self.mark_suspicious(user_id, "Too many failed join attempts")
    
    def is_main_group(self, chat_id: int) -> bool:
        """Check if message is from main group"""
        return chat_id == settings.MAIN_GROUP_ID
    
    def is_owner(self, user_id: int) -> bool:
        """Check if user is owner"""
        return user_id in settings.OWNER_IDS
    
    def is_admin(self, user_id: int) -> bool:
        """Check if user is admin or owner"""
        return user_id in settings.ADMIN_IDS or self.is_owner(user_id)
    
    # ═══════════════════════════════════════════════════════
    # Rate Limiting
    # ═══════════════════════════════════════════════════════
    
    async def check_rate_limit(
        self,
        user_id: int,
        action: str,
        max_requests: Optional[int] = None,
        window: int = 60
    ) -> tuple[bool, int, int]:
        """
        Check rate limit for user action
        
        Returns:
            (is_limited, current_count, remaining_time)
        """
        if not settings.RATE_LIMIT_ENABLED:
            return False, 0, 0
        
        # Owner bypass
        if self.is_owner(user_id):
            return False, 0, 0
        
        if max_requests is None:
            max_requests = settings.MAX_REQUESTS_PER_MINUTE
        
        key = f"ratelimit:{action}:{user_id}"
        
        # Get current count
        count = await cache.get(key, 0)
        if isinstance(count, str):
            count = int(count)
        
        # Check if limited
        if count >= max_requests:
            ttl = await cache.ttl(key)
            return True, count, ttl
        
        # Increment counter
        new_count = await cache.incr(key)
        
        # Set expiry on first request
        if new_count == 1:
            await cache.expire(key, window)
        
        return False, new_count, 0
    
    async def check_spam(self, user_id: int, message_text: str) -> bool:
        """
        Check if message is spam
        
        Returns:
            True if spam detected
        """
        # Get recent messages
        key = f"messages:{user_id}"
        messages = await cache.lrange(key, 0, settings.SPAM_THRESHOLD)
        
        # Add current message
        await cache.lpush(key, {
            "text": message_text,
            "time": time.time()
        })
        await cache.expire(key, settings.SPAM_WINDOW)
        
        # Check for spam patterns
        if len(messages) >= settings.SPAM_THRESHOLD:
            # Check if messages are identical
            texts = [m.get("text", "") for m in messages]
            if len(set(texts)) == 1:
                await self.mark_suspicious(user_id, "Spam detected - identical messages")
                return True
            
            # Check if too many messages in short time
            times = [m.get("time", 0) for m in messages]
            if times and (max(times) - min(times)) < settings.SPAM_WINDOW:
                await self.mark_suspicious(user_id, "Spam detected - too many messages")
                return True
        
        return False
    
    # ═══════════════════════════════════════════════════════
    # Anti-Cheat & Fraud Detection
    # ═══════════════════════════════════════════════════════
    
    async def detect_suspicious_activity(
        self, 
        user_id: int, 
        activity: str, 
        amount: Optional[int] = None
    ) -> bool:
        """
        Detect suspicious activity
        
        Returns:
            True if activity is suspicious
        """
        suspicious = False
        reasons = []
        
        # Check for impossible earnings
        if amount and amount > settings.MAX_DAILY_EARNINGS:
            suspicious = True
            reasons.append(f"Impossible earning: {amount}")
        
        # Check activity frequency
        key = f"activity:{activity}:{user_id}"
        count = await cache.incr(key)
        
        if count == 1:
            await cache.expire(key, 86400)  # 24 hours
        
        # Define thresholds
        thresholds = {
            "work": 200,  # Max 200 works per day
            "coin": 300,  # Max 300 coins per day
            "game": 1000,  # Max 1000 games per day
            "transfer": 50,  # Max 50 transfers per day
        }
        
        threshold = thresholds.get(activity, 100)
        
        if count > threshold:
            suspicious = True
            reasons.append(f"Excessive {activity}: {count} times")
        
        # Check for bot-like behavior
        if await self._check_bot_behavior(user_id):
            suspicious = True
            reasons.append("Bot-like behavior detected")
        
        if suspicious:
            await self.mark_suspicious(user_id, ", ".join(reasons))
        
        return suspicious
    
    async def _check_bot_behavior(self, user_id: int) -> bool:
        """Check for bot-like patterns"""
        key = f"actions:{user_id}"
        actions = await cache.lrange(key, 0, 100)
        
        if len(actions) < 10:
            return False
        
        # Check for perfectly timed actions
        times = [a.get("time", 0) for a in actions[-10:]]
        intervals = [times[i+1] - times[i] for i in range(len(times)-1)]
        
        # If all intervals are suspiciously similar (within 1 second)
        if len(set(int(i) for i in intervals)) <= 2:
            return True
        
        return False
    
    async def mark_suspicious(self, user_id: int, reason: str):
        """Mark user as suspicious"""
        self.suspicious_users.add(user_id)
        
        # Increment suspicious activity counter
        key = f"suspicious:{user_id}"
        count = await cache.incr(key)
        
        # Store reason
        await cache.lpush(f"suspicious_reasons:{user_id}", {
            "reason": reason,
            "time": datetime.utcnow().isoformat()
        })
        
        logger.warning(f"🚨 Suspicious activity from user {user_id}: {reason}")
        
        # Auto-ban if threshold exceeded
        if settings.AUTO_BAN_CHEATERS and count >= settings.SUSPICIOUS_ACTIVITY_THRESHOLD:
            logger.critical(f"🚫 Auto-banning user {user_id} for suspicious activity")
            # Will be implemented in user service
    
    async def is_suspicious(self, user_id: int) -> bool:
        """Check if user is marked as suspicious"""
        return user_id in self.suspicious_users
    
    # ═══════════════════════════════════════════════════════
    # Transaction Validation
    # ═══════════════════════════════════════════════════════
    
    async def validate_transaction(
        self,
        user_id: int,
        amount: int,
        transaction_type: str,
        target_user_id: Optional[int] = None
    ) -> tuple[bool, Optional[str]]:
        """
        Validate transaction for security
        
        Returns:
            (is_valid, error_message)
        """
        if not settings.VALIDATE_TRANSACTIONS:
            return True, None
        
        # Check for negative amounts
        if amount < 0:
            return False, "مقدار نامعتبر است"
        
        # Check for suspiciously large amounts
        if amount > settings.MAX_BALANCE:
            await self.mark_suspicious(user_id, f"Suspiciously large transaction: {amount}")
            return False, "مقدار بیش از حد مجاز است"
        
        # Check transaction frequency
        key = f"transactions:{user_id}"
        count = await cache.incr(key)
        
        if count == 1:
            await cache.expire(key, 60)  # 1 minute window
        
        if count > 20:  # Max 20 transactions per minute
            return False, "تعداد تراکنش‌ها بیش از حد مجاز است. لطفاً کمی صبر کنید"
        
        # Check for self-transfer
        if target_user_id and target_user_id == user_id:
            return False, "نمی‌توانید به خودتان انتقال دهید"
        
        # Check if user is suspicious
        if await self.is_suspicious(user_id):
            return False, "حساب شما به دلیل فعالیت مشکوک محدود شده است"
        
        return True, None
    
    # ═══════════════════════════════════════════════════════
    # Input Validation
    # ═══════════════════════════════════════════════════════
    
    def validate_amount(
        self,
        amount_str: str,
        min_amount: int = 0,
        max_amount: Optional[int] = None
    ) -> tuple[bool, Optional[int], Optional[str]]:
        """
        Validate amount input
        
        Returns:
            (is_valid, parsed_amount, error_message)
        """
        # Check if numeric
        if not amount_str.isdigit() and amount_str != "*":
            return False, None, "مقدار باید عدد باشد"
        
        if amount_str == "*":
            return True, None, None  # Will be handled by caller
        
        try:
            amount = int(amount_str)
        except ValueError:
            return False, None, "مقدار نامعتبر است"
        
        # Check range
        if amount <= min_amount:
            return False, None, f"مقدار باید بیشتر از {min_amount:,} باشد"
        
        if max_amount and amount > max_amount:
            return False, None, f"مقدار نباید بیشتر از {max_amount:,} باشد"
        
        return True, amount, None
    
    def sanitize_input(self, text: str) -> str:
        """Sanitize user input"""
        # Remove potentially dangerous characters
        text = text.strip()
        
        # Remove HTML tags
        import re
        text = re.sub(r'<[^>]+>', '', text)
        
        # Remove excessive whitespace
        text = ' '.join(text.split())
        
        return text
    
    # ═══════════════════════════════════════════════════════
    # IP & Device Tracking (Optional)
    # ═══════════════════════════════════════════════════════
    
    def get_request_hash(self, user_id: int, ip: Optional[str] = None) -> str:
        """Generate unique hash for request"""
        data = f"{user_id}:{ip or 'unknown'}:{datetime.utcnow().date()}"
        return hashlib.sha256(data.encode()).hexdigest()
    
    async def track_device(self, user_id: int, device_info: Dict[str, Any]):
        """Track user device"""
        key = f"device:{user_id}"
        await cache.hset(key, "last_seen", device_info)
        await cache.expire(key, 86400 * 30)  # 30 days
    
    # ═══════════════════════════════════════════════════════
    # Cleanup
    # ═══════════════════════════════════════════════════════
    
    async def cleanup_old_data(self):
        """Cleanup old security data"""
        # Clear old failed attempts
        await cache.delete_pattern("failed_join:*")
        await cache.delete_pattern("suspicious_reasons:*")
        
        logger.info("🧹 Security data cleanup completed")


# Global security manager
security = SecurityManager()


# ═══════════════════════════════════════════════════════
# Decorators for easy use
# ═══════════════════════════════════════════════════════

def require_group(func: Callable):
    """Decorator to require main group"""
    @wraps(func)
    async def wrapper(update: Update, context: ContextTypes.DEFAULT_TYPE, *args, **kwargs):
        if not update.effective_chat:
            return
        
        if not security.is_main_group(update.effective_chat.id):
            await update.message.reply_text(
                "⚠️ این ربات فقط در گروه اصلی کار می‌کند!"
            )
            return
        
        return await func(update, context, *args, **kwargs)
    
    return wrapper


def require_channel(func: Callable):
    """Decorator to require channel membership"""
    @wraps(func)
    async def wrapper(update: Update, context: ContextTypes.DEFAULT_TYPE, *args, **kwargs):
        user_id = update.effective_user.id
        
        # Owner bypass
        if security.is_owner(user_id):
            return await func(update, context, *args, **kwargs)
        
        # Check membership
        is_member = await security.check_channel_membership(context, user_id)
        
        if not is_member:
            # Send glass button
            from telegram import InlineKeyboardButton, InlineKeyboardMarkup
            
            keyboard = [
                [InlineKeyboardButton(
                    "🔗 عضویت در کانال",
                    url=f"https://t.me/{settings.REQUIRED_CHANNEL.replace('@', '')}"
                )],
                [InlineKeyboardButton(
                    "✅ عضو شدم!",
                    callback_data="check_membership"
                )]
            ]
            reply_markup = InlineKeyboardMarkup(keyboard)
            
            await update.message.reply_text(
                "⚠️ برای استفاده از ربات ابتدا در کانال عضو شوید!\n\n"
                f"کانال: {settings.REQUIRED_CHANNEL}",
                reply_markup=reply_markup
            )
            return
        
        return await func(update, context, *args, **kwargs)
    
    return wrapper


def require_admin(func: Callable):
    """Decorator to require admin access"""
    @wraps(func)
    async def wrapper(update: Update, context: ContextTypes.DEFAULT_TYPE, *args, **kwargs):
        user_id = update.effective_user.id
        
        if not security.is_admin(user_id):
            await update.message.reply_text(
                "⛔ این دستور فقط برای ادمین‌ها است!"
            )
            return
        
        return await func(update, context, *args, **kwargs)
    
    return wrapper


def require_owner(func: Callable):
    """Decorator to require owner access"""
    @wraps(func)
    async def wrapper(update: Update, context: ContextTypes.DEFAULT_TYPE, *args, **kwargs):
        user_id = update.effective_user.id
        
        if not security.is_owner(user_id):
            await update.message.reply_text(
                "⛔ این دستور فقط برای مالک ربات است!"
            )
            return
        
        return await func(update, context, *args, **kwargs)
    
    return wrapper


def rate_limit(action: str, max_requests: int = None, window: int = 60):
    """Decorator for rate limiting"""
    def decorator(func: Callable):
        @wraps(func)
        async def wrapper(update: Update, context: ContextTypes.DEFAULT_TYPE, *args, **kwargs):
            user_id = update.effective_user.id
            
            is_limited, count, remaining_time = await security.check_rate_limit(
                user_id, action, max_requests, window
            )
            
            if is_limited:
                minutes, seconds = divmod(remaining_time, 60)
                await update.message.reply_text(
                    f"⏳ لطفاً {minutes:02d}:{seconds:02d} دیگر صبر کنید!"
                )
                return
            
            return await func(update, context, *args, **kwargs)
        
        return wrapper
    return decorator


def check_spam(func: Callable):
    """Decorator to check for spam"""
    @wraps(func)
    async def wrapper(update: Update, context: ContextTypes.DEFAULT_TYPE, *args, **kwargs):
        user_id = update.effective_user.id
        message_text = update.message.text or ""
        
        if await security.check_spam(user_id, message_text):
            await update.message.reply_text(
                "⚠️ اسپم شناسایی شد! لطفاً کمی صبر کنید."
            )
            return
        
        return await func(update, context, *args, **kwargs)
    
    return wrapper
