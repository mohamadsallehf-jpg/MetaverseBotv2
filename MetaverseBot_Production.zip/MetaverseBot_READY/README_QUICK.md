# 🎮 ربات بازی متاورس تلگرام

**نسخه بهینه شده برای سرور - آماده استفاده فوری!**

---

## ⚡ نصب سریع (3 دقیقه)

```bash
# 1. استخراج فایل
unzip MetaverseBot.zip
cd MetaverseBot

# 2. اجرای نصب
chmod +x setup.sh
./setup.sh

# 3. تنظیم env
nano env
# توکن، آیدی‌ها و کانال رو وارد کن

# 4. شروع!
./start.sh
```

---

## 📋 چیزایی که نیاز داری

### از تلگرام:
1. **توکن ربات** - از [@BotFather](https://t.me/BotFather)
   - `/newbot` بزن و توکن رو بگیر

2. **آیدی خودت** - از [@userinfobot](https://t.me/userinfobot)
   - `/start` بزن و آیدی رو کپی کن

3. **آیدی گروه** - از [@userinfobot](https://t.me/userinfobot)
   - پیامی تو گروه بفرست و به userinfobot فوروارد کن
   - ربات رو حتماً ادمین گروه کن!

4. **کانال** - یه کانال Public بساز
   - یه یوزرنیم بهش بده (مثلاً @MyChannel)
   - ربات رو ادمین کانال کن

---

## 🚀 نصب روی VPS

### 1. اتصال به سرور
```bash
ssh root@IP_SERVERET
```

### 2. آماده‌سازی
```bash
apt update && apt upgrade -y
apt install -y python3 python3-pip python3-venv screen unzip
```

### 3. آپلود و نصب
```bash
cd /root
unzip MetaverseBot.zip
cd MetaverseBot
./setup.sh
```

### 4. تنظیم فایل env
```bash
nano env
```

این مقادیر رو پر کن:
```env
BOT_TOKEN=توکن_از_BotFather
OWNER_IDS=آیدی_عددی_خودت
MAIN_GROUP_ID=-آیدی_گروه_با_منفی
REQUIRED_CHANNEL=@یوزرنیم_کانال
```

ذخیره: `Ctrl+O` → `Enter` → `Ctrl+X`

### 5. اجرا
```bash
./start.sh
```

---

## 📱 دستورات

### کاربران:
- `/start` - شروع
- `/help` - راهنما
- `/profile` - پروفایل
- `/balance` - موجودی
- `/daily` - جایزه روزانه

### بازی‌ها:
- `/dice` - تاس
- `/slot` - اسلات
- `/coinflip` - سکه

### ادمین:
- `/admin` - پنل ادمین
- `/stats` - آمار

---

## 🔧 مدیریت

```bash
./start.sh      # شروع ربات
./stop.sh       # توقف ربات  
./restart.sh    # ریستارت
./status.sh     # وضعیت
```

### لاگ‌ها
```bash
tail -f logs/bot.log    # مشاهده زنده
tail -100 logs/bot.log  # 100 خط آخر
```

### بکاپ
```bash
cp metaverse_bot.db backups/backup_$(date +%Y%m%d).db
```

---

## 🐛 مشکل داری؟

### ربات استارت نمی‌شه؟

**1. چک کن محیط مجازی فعاله:**
```bash
source venv/bin/activate
```

**2. لاگ رو ببین:**
```bash
tail -50 logs/bot.log
```

**3. تنظیمات رو بررسی کن:**
```bash
cat env | grep BOT_TOKEN
```

### خطای ModuleNotFoundError?
```bash
source venv/bin/activate
pip install -r requirements.txt
```

### خطای Invalid Token?
- توکن جدید از @BotFather بگیر
- فایل env رو چک کن

### ربات پیام نمی‌فرسته؟
- مطمئن شو ربات ادمین گروه هست
- مطمئن شو ربات ادمین کانال هست
- آیدی گروه باید با منفی شروع شه

---

## ✨ ویژگی‌ها

- ✅ سیستم اقتصادی کامل
- ✅ بازی‌های متنوع
- ✅ رتبه‌بندی
- ✅ سیستم VIP
- ✅ پنل ادمین
- ✅ Auto-restart
- ✅ مدیریت خطا
- ✅ لاگینگ حرفه‌ای

---

## 📚 فایل‌های مفید

- `راهنمای_نصب_کامل_VPS.md` - راهنمای کامل
- `راهنمای_رفع_مشکلات.md` - حل مشکلات
- `env.example` - نمونه تنظیمات

---

## 💡 نکته مهم

**همیشه:**
- محیط مجازی رو فعال کن: `source venv/bin/activate`
- از screen استفاده کن: `screen -S metaverse`
- روزانه بکاپ بگیر!

---

**ساخته شده با ❤️ برای جامعه فارسی**

🎮 موفق باشی!
