#!/bin/bash

# ═══════════════════════════════════════════════════════
# 📊 MetaverseBot - Status Check Script
# ═══════════════════════════════════════════════════════

GREEN='\033[0;32m'
RED='\033[0;31m'
YELLOW='\033[1;33m'
CYAN='\033[0;36m'
NC='\033[0m'

echo -e "${CYAN}"
echo "╔══════════════════════════════════════════╗"
echo "║    📊 Bot Status                        ║"
echo "╚══════════════════════════════════════════╝"
echo -e "${NC}"

# Check if bot is running
if pgrep -f "python.*main.py" > /dev/null; then
    echo -e "${GREEN}✅ Bot Status: RUNNING${NC}"
    
    # Get PID
    PID=$(pgrep -f "python.*main.py")
    echo -e "   PID: ${CYAN}$PID${NC}"
    
    # Get uptime
    UPTIME=$(ps -p $PID -o etime= | tr -d ' ')
    echo -e "   Uptime: ${CYAN}$UPTIME${NC}"
    
    # Get memory usage
    MEM=$(ps -p $PID -o rss= | awk '{print $1/1024 " MB"}')
    echo -e "   Memory: ${CYAN}$MEM${NC}"
    
    # Check screen session
    if screen -ls | grep -q "metaverse"; then
        echo -e "   Screen: ${GREEN}Active${NC}"
        echo -e "   Attach: ${CYAN}screen -r metaverse${NC}"
    fi
else
    echo -e "${RED}❌ Bot Status: NOT RUNNING${NC}"
    echo ""
    echo "Start bot with:"
    echo -e "${CYAN}./start.sh${NC}"
fi

echo ""
echo -e "${CYAN}╔══════════════════════════════════════════╗${NC}"
echo -e "${CYAN}║    📝 Recent Logs                       ║${NC}"
echo -e "${CYAN}╚══════════════════════════════════════════╝${NC}"

if [ -f "logs/bot.log" ]; then
    tail -10 logs/bot.log
else
    echo -e "${YELLOW}No logs found${NC}"
fi

echo ""
echo "Commands:"
echo -e "  ${CYAN}./start.sh${NC}   - Start bot"
echo -e "  ${CYAN}./stop.sh${NC}    - Stop bot"
echo -e "  ${CYAN}./restart.sh${NC} - Restart bot"
echo -e "  ${CYAN}tail -f logs/bot.log${NC} - Watch logs"
