#!/bin/bash
set -e

# ═══════════════════════════════════════════════════════
# 🚀 MetaverseBot - Production Setup Script
# ═══════════════════════════════════════════════════════

RED='\033[0;31m'
GREEN='\033[0;32m'
YELLOW='\033[1;33m'
BLUE='\033[0;34m'
PURPLE='\033[0;35m'
CYAN='\033[0;36m'
NC='\033[0m'

print_header() {
    echo -e "${PURPLE}"
    echo "╔══════════════════════════════════════════════════════╗"
    echo "║         🎮 MetaverseBot Production Setup            ║"
    echo "║              نصب حرفه‌ای ربات متاورس                 ║"
    echo "╚══════════════════════════════════════════════════════╝"
    echo -e "${NC}"
}

print_step() {
    echo -e "${CYAN}➜ $1${NC}"
}

print_success() {
    echo -e "${GREEN}✅ $1${NC}"
}

print_error() {
    echo -e "${RED}❌ $1${NC}"
}

print_warning() {
    echo -e "${YELLOW}⚠️  $1${NC}"
}

print_info() {
    echo -e "${BLUE}ℹ️  $1${NC}"
}

print_header

# ═══════════════════════════════════════════════════════
# Step 1: System Check
# ═══════════════════════════════════════════════════════
print_step "Step 1/7: Checking system requirements..."

if command -v python3 &> /dev/null; then
    PYTHON_VERSION=$(python3 --version | cut -d' ' -f2)
    print_success "Python $PYTHON_VERSION found"
else
    print_error "Python 3 not found!"
    exit 1
fi

# ═══════════════════════════════════════════════════════
# Step 2: Install System Dependencies
# ═══════════════════════════════════════════════════════
print_step "Step 2/7: Installing system dependencies..."

if command -v apt &> /dev/null; then
    sudo apt update -qq 2>&1 | grep -v "^Reading" || true
    sudo apt install -y -qq python3-venv python3-dev build-essential screen 2>&1 | grep -v "^Reading" || true
    print_success "System dependencies installed"
fi

# ═══════════════════════════════════════════════════════
# Step 3: Create Virtual Environment
# ═══════════════════════════════════════════════════════
print_step "Step 3/7: Creating virtual environment..."

if [ -d "venv" ]; then
    print_warning "Virtual environment already exists"
else
    python3 -m venv venv
    print_success "Virtual environment created"
fi

# ═══════════════════════════════════════════════════════
# Step 4: Install Dependencies
# ═══════════════════════════════════════════════════════
print_step "Step 4/7: Installing Python dependencies..."
print_info "This may take 3-5 minutes..."

source venv/bin/activate
pip install --upgrade pip -q
pip install -r requirements.txt -q
print_success "Dependencies installed"

# ═══════════════════════════════════════════════════════
# Step 5: Create Directories
# ═══════════════════════════════════════════════════════
print_step "Step 5/7: Creating directories..."

mkdir -p logs backups temp data
chmod 755 logs backups temp data
print_success "Directories created"

# ═══════════════════════════════════════════════════════
# Step 6: Setup Configuration
# ═══════════════════════════════════════════════════════
print_step "Step 6/7: Setting up configuration..."

if [ ! -f "env" ]; then
    if [ -f "env.example" ]; then
        cp env.example env
        print_success "Configuration file created"
        print_warning "⚠️  Edit 'env' file with your settings!"
    fi
else
    print_success "Configuration file exists"
fi

# ═══════════════════════════════════════════════════════
# Step 7: Set Permissions
# ═══════════════════════════════════════════════════════
print_step "Step 7/7: Setting permissions..."

chmod +x *.sh 2>/dev/null || true
chmod 644 env 2>/dev/null || true
print_success "Permissions set"

# ═══════════════════════════════════════════════════════
# Complete
# ═══════════════════════════════════════════════════════
echo ""
echo -e "${GREEN}╔══════════════════════════════════════════╗${NC}"
echo -e "${GREEN}║    ✅ Installation Complete!             ║${NC}"
echo -e "${GREEN}╚══════════════════════════════════════════╝${NC}"
echo ""
print_warning "Next Steps:"
echo ""
echo "1️⃣  Edit configuration: ${CYAN}nano env${NC}"
echo "2️⃣  Start bot: ${CYAN}./start.sh${NC}"
echo "3️⃣  Check logs: ${CYAN}tail -f logs/bot.log${NC}"
echo ""
print_success "Happy gaming! 🎮"
