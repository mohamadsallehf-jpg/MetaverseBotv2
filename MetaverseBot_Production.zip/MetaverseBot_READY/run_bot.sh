#!/bin/bash

# Activate virtual environment
source venv/bin/activate

# Run bot
python main.py
