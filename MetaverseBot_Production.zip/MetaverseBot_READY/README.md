# 🎮 Advanced Metaverse Bot - ربات متاورس پیشرفته

<div align="center">

![Python](https://img.shields.io/badge/Python-3.9+-blue.svg)
![License](https://img.shields.io/badge/License-MIT-green.svg)
![Status](https://img.shields.io/badge/Status-Production%20Ready-success.svg)

یک ربات متاورس کامل و پیشرفته برای تلگرام با معماری مدرن و امکانات حرفه‌ای

[ویژگی‌ها](#-ویژگی‌ها) • [نصب](#-نصب-و-راه‌اندازی) • [تنظیمات](#️-تنظیمات) • [مستندات](#-مستندات)

</div>

---

## 📋 فهرست مطالب

- [ویژگی‌ها](#-ویژگی‌ها)
- [معماری](#-معماری)
- [پیش‌نیازها](#-پیش‌نیازها)
- [نصب و راه‌اندازی](#-نصب-و-راه‌اندازی)
- [تنظیمات](#️-تنظیمات)
- [دستورات](#-دستورات)
- [API](#-api)
- [دیباگ و نگهداری](#-دیباگ-و-نگهداری)
- [عیب‌یابی](#-عیب‌یابی)

---

## ✨ ویژگی‌ها

### 🎯 ویژگی‌های اصلی

- **🔐 امنیت پیشرفته**
  - Rate limiting هوشمند
  - Anti-spam و anti-cheat
  - تشخیص فعالیت مشکوک
  - اعتبارسنجی تراکنش‌ها
  - جوین چکر با دکمه‌های شیشه‌ای

- **💾 دیتابیس قدرتمند**
  - SQLAlchemy ORM با پشتیبانی async
  - PostgreSQL / SQLite
  - Migration ساده با Alembic
  - نسخه‌برداری خودکار

- **🔴 کش Redis**
  - کش کاربران و داده‌ها
  - سشن منیجمنت
  - Rate limiting
  - Leaderboard های بهینه

- **📊 آمار و تحلیل**
  - Dashboard کامل
  - نمودارهای زنده
  - تریکینگ فعالیت
  - گزارش‌دهی پیشرفته

### 🎮 سیستم‌های بازی

#### 💰 سیستم اقتصادی
- 4 نوع ارز (سکه، طلا، الماس، دلار)
- سیستم بانکی با سود
- صرافی ارز
- کارمزد تراکنش

#### 💼 سیستم شغلی
- 10 شغل متنوع
- سیستم تجربه شغلی
- توانایی‌های ویژه هر شغل
- ارتقای شغلی

#### ⚔️ سلاح‌ها
- 35+ سلاح از سرد تا مدرن
- سیستم قدرت و ارتقا
- 5 دسته‌بندی
- تجربه سلاح

#### 🏠 املاک و کارخانه
- 4 نوع خانه (کاهش مالیات)
- 4 نوع کارخانه (درآمد غیرفعال)
- سیستم کارگر
- مدیریت تولید

#### 🎲 بازی‌ها
- Slot Machine (🎰)
- Dice Game (🎲)
- بازی‌های شرط‌بندی
- Challenge با دیگران
- جکپات

#### 💎 سیستم VIP
- 3 سطح VIP
- ضریب درآمد و بازی بالاتر
- کولداون کمتر
- شغل‌های ویژه
- بونس روزانه

### 🛠️ ویژگی‌های فنی

- **Async/Await** برای عملکرد بهینه
- **Type Hints** کامل
- **Logging** پیشرفته با Loguru
- **Error Handling** جامع
- **Decorators** برای کدنویسی تمیز
- **Middleware System** قدرتمند
- **Plugin Architecture** برای توسعه
- **API REST** اختیاری
- **Web Panel** مدیریتی
- **Docker Support**

---

## 🏗️ معماری

```
MetaverseBot/
├── config/              # تنظیمات و پیکربندی
│   ├── settings.py      # تنظیمات اصلی
│   └── __init__.py
├── models/              # مدل‌های دیتابیس
│   ├── base.py          # Base و DB Manager
│   ├── user.py          # مدل کاربر
│   ├── transaction.py   # تراکنش‌ها
│   └── log.py           # لاگ‌ها
├── services/            # سرویس‌های تجاری
│   ├── cache.py         # Redis cache
│   ├── user_service.py  # سرویس کاربر
│   └── __init__.py
├── middlewares/         # میدلور‌ها
│   ├── security.py      # امنیت و rate limit
│   └── __init__.py
├── handlers/            # هندلرهای دستورات
│   ├── user_handlers.py
│   ├── economy_handlers.py
│   ├── game_handlers.py
│   ├── admin_handlers.py
│   └── __init__.py
├── utils/               # توابع کمکی
├── plugins/             # پلاگین‌های اضافی
├── data/                # داده‌ها (JSON/DB)
├── logs/                # فایل‌های لاگ
├── assets/              # تصاویر و فایل‌ها
├── backups/             # نسخه پشتیبان
├── main.py              # نقطه ورود
├── requirements.txt     # وابستگی‌ها
├── .env.example         # نمونه env
├── alembic/             # Database migrations
└── README.md
```

---

## 📦 پیش‌نیازها

### سیستم عامل
- Ubuntu 20.04+ / Debian 11+
- CentOS 8+ / Rocky Linux 8+
- Docker (اختیاری)

### نرم‌افزار
- Python 3.9+
- PostgreSQL 13+ یا SQLite
- Redis 6+ (اختیاری اما توصیه می‌شود)
- Git

### سخت‌افزار توصیه‌شده (VPS)
- CPU: 2 Core
- RAM: 2GB+
- Storage: 20GB+
- Network: 100Mbps+

---

## 🚀 نصب و راه‌اندازی

### روش 1: نصب دستی

#### 1️⃣ نصب پیش‌نیازها

```bash
# آپدیت سیستم
sudo apt update && sudo apt upgrade -y

# نصب Python و ابزارها
sudo apt install python3.9 python3-pip python3-venv git -y

# نصب PostgreSQL (اختیاری)
sudo apt install postgresql postgresql-contrib -y

# نصب Redis (اختیاری)
sudo apt install redis-server -y
```

#### 2️⃣ کلون پروژه

```bash
git clone https://github.com/yourusername/metaverse-bot.git
cd metaverse-bot
```

#### 3️⃣ ساخت محیط مجازی

```bash
python3 -m venv venv
source venv/bin/activate
```

#### 4️⃣ نصب وابستگی‌ها

```bash
pip install --upgrade pip
pip install -r requirements.txt
```

#### 5️⃣ تنظیم پایگاه داده

**PostgreSQL:**
```bash
# ورود به PostgreSQL
sudo -u postgres psql

# ساخت دیتابیس و کاربر
CREATE DATABASE metaverse_bot;
CREATE USER bot_user WITH PASSWORD 'your_password';
GRANT ALL PRIVILEGES ON DATABASE metaverse_bot TO bot_user;
\q
```

**Redis:**
```bash
# شروع Redis
sudo systemctl start redis
sudo systemctl enable redis

# تست اتصال
redis-cli ping
# باید "PONG" برگرداند
```

#### 6️⃣ تنظیم متغیرهای محیطی

```bash
cp .env.example .env
nano .env
```

تنظیمات مورد نیاز:
```env
# Bot Configuration
BOT_TOKEN=YOUR_BOT_TOKEN_FROM_BOTFATHER
BOT_USERNAME=your_bot_username

# Group & Channel
MAIN_GROUP_ID=-1001234567890
REQUIRED_CHANNEL=@your_channel

# Owner & Admins
OWNER_IDS=123456789
ADMIN_IDS=987654321,456789123

# Database
DATABASE_URL=postgresql+asyncpg://bot_user:your_password@localhost/metaverse_bot
# یا برای SQLite:
# DATABASE_URL=sqlite+aiosqlite:///./metaverse_bot.db

# Redis
REDIS_HOST=localhost
REDIS_PORT=6379
REDIS_PASSWORD=
REDIS_ENABLED=true

# Security
SECRET_KEY=your-super-secret-key-32-chars-min
JWT_SECRET=another-secret-key
ENCRYPTION_KEY=32-character-encryption-key!!

# Rate Limiting
MAX_REQUESTS_PER_MINUTE=30
MAX_REQUESTS_PER_HOUR=500
```

#### 7️⃣ مهاجرت دیتابیس (اگر از PostgreSQL استفاده می‌کنید)

```bash
# ساخت migration اولیه
alembic revision --autogenerate -m "Initial migration"

# اعمال migration
alembic upgrade head
```

#### 8️⃣ اجرای ربات

```bash
# حالت توسعه
python main.py

# حالت تولید با nohup
nohup python main.py > bot.log 2>&1 &

# یا با screen
screen -S metaverse-bot
python main.py
# Ctrl+A, D برای detach
```

### روش 2: با Docker

```bash
# Build
docker build -t metaverse-bot .

# Run
docker run -d \
  --name metaverse-bot \
  --env-file .env \
  -v ./data:/app/data \
  -v ./logs:/app/logs \
  --restart unless-stopped \
  metaverse-bot

# View logs
docker logs -f metaverse-bot
```

### روش 3: با Docker Compose

```bash
docker-compose up -d
docker-compose logs -f
```

---

## ⚙️ تنظیمات

### دریافت توکن ربات

1. به [@BotFather](https://t.me/BotFather) در تلگرام بروید
2. دستور `/newbot` را بزنید
3. نام و یوزرنیم ربات را وارد کنید
4. توکن را کپی و در `.env` قرار دهید

### دریافت آیدی گروه

1. ربات را به گروه اضافه کنید
2. ربات را ادمین کنید
3. به [@userinfobot](https://t.me/userinfobot) پیام دهید
4. پیامی در گروه بفرستید و به ربات فوروارد کنید
5. آیدی گروه را کپی کنید (با منفی)

### تنظیم کانال اجباری

1. ربات را به کانال اضافه کنید
2. ربات را ادمین کانال کنید
3. یوزرنیم کانال را با @ در `.env` قرار دهید

---

## 📝 دستورات

### دستورات عمومی

```
/start - شروع و ثبت‌نام
/help - راهنمای کامل
/info - اطلاعات حساب
/profile - پروفایل کامل
```

### دستورات اقتصادی

```
/coin - دریافت سکه رایگان (هر 5 دقیقه)
/work - کار کردن (هر 10 دقیقه)
/daily - هدیه روزانه (هر 24 ساعت)
/weekly - هدیه هفتگی
/monthly - هدیه ماهانه

/pay @user مقدار - انتقال سکه
/transfer مقدار - واریز به بانک
/withdraw مقدار - برداشت از بانک

/balance - مشاهده موجودی
/bank - اطلاعات بانک
```

### بازار و خرید

```
/market - بازار اصلی
/guns - لیست سلاح‌ها
/buygun نام - خرید سلاح
/buyusd مقدار - خرید دلار
/sellusd مقدار - فروش دلار
/buyhome - خرید خانه
/buyfactory - خرید کارخانه
```

### بازی‌ها

```
/bet مقدار - شرط‌بندی
/slot مقدار - اسلات
/dice مقدار - تاس
/challenge @user مقدار - چلنج
```

### شغل

```
/jobs - لیست مشاغل
/setjob نام - تغییر شغل
/jobinfo - اطلاعات شغل
```

### آمار

```
/top - برترین‌ها (سکه)
/toplevel - برترین‌ها (سطح)
/topwins - برترین‌ها (برد)
/stats - آمار شخصی
```

### VIP

```
/getvip - خرید VIP
/vipinfo - اطلاعات VIP
```

### دستورات ادمین

```
/admin - پنل ادمین
/ban @user [reason] - بن کاربر
/unban @user - رفع بن
/mute @user [minutes] - سکوت
/warn @user [reason] - اخطار
/addcoin @user مقدار - افزودن سکه
/stats - آمار کلی
/broadcast پیام - ارسال به همه
```

### دستورات مالک

```
/owner - پنل مالک
/backup - بکاپ دیتابیس
/restore - بازیابی بکاپ
/logs - مشاهده لاگ‌ها
/addadmin @user - افزودن ادمین
/systeminfo - اطلاعات سیستم
```

---

## 🐛 دیباگ و نگهداری

### مشاهده لاگ‌ها

```bash
# لاگ‌های اصلی
tail -f logs/bot.log

# لاگ‌های خطا
grep ERROR logs/bot.log

# لاگ‌های امنیتی
tail -f logs/security.log
```

### بکاپ دیتابیس

```bash
# PostgreSQL
pg_dump -U bot_user metaverse_bot > backup_$(date +%Y%m%d).sql

# SQLite
cp metaverse_bot.db backups/backup_$(date +%Y%m%d).db
```

### بازیابی

```bash
# PostgreSQL
psql -U bot_user metaverse_bot < backup_20240101.sql

# SQLite
cp backups/backup_20240101.db metaverse_bot.db
```

### مانیتورینگ

```bash
# CPU و RAM
htop

# دیسک
df -h

# نت‌ورک
iftop

# پراسس‌های ربات
ps aux | grep python
```

---

## 🔧 عیب‌یابی

### ربات استارت نمی‌شود

**علت:** توکن اشتباه
```bash
# بررسی توکن
echo $BOT_TOKEN
```

**راه حل:** توکن صحیح را در `.env` قرار دهید

---

### Redis به ربات وصل نمی‌شود

**علت:** Redis در حال اجرا نیست
```bash
# استارت Redis
sudo systemctl start redis
sudo systemctl status redis
```

---

### دیتابیس خطا می‌دهد

```bash
# بررسی اتصال PostgreSQL
psql -U bot_user -d metaverse_bot

# اجرای migration ها
alembic upgrade head
```

---

## 📊 عملکرد و بهینه‌سازی

### بهینه‌سازی Redis

```bash
# تنظیمات Redis
sudo nano /etc/redis/redis.conf

# افزایش max memory
maxmemory 512mb
maxmemory-policy allkeys-lru
```

### بهینه‌سازی PostgreSQL

```sql
-- افزایش connection pool
ALTER SYSTEM SET max_connections = '200';
ALTER SYSTEM SET shared_buffers = '256MB';

-- بازآماد سازی
SELECT pg_reload_conf();
```

---

## 🤝 مشارکت

برای مشارکت:
1. Fork کنید
2. Branch جدید بسازید
3. تغییرات را commit کنید
4. Push کنید
5. Pull Request بزنید

---

## 📜 مجوز

این پروژه تحت مجوز MIT منتشر شده است.

---

## 🙏 قدردانی

- [python-telegram-bot](https://github.com/python-telegram-bot/python-telegram-bot)
- [SQLAlchemy](https://www.sqlalchemy.org/)
- [Redis](https://redis.io/)
- [Loguru](https://github.com/Delgan/loguru)

---

## 📞 پشتیبانی

- 📧 Email: support@yourdomain.com
- 💬 Telegram: @your_support
- 🐛 Issues: GitHub Issues

---

<div align="center">

**توسعه داده شده با ❤️ برای جامعه تلگرام**

⭐ اگر این پروژه را دوست دارید، یک ستاره بدهید!

</div>
