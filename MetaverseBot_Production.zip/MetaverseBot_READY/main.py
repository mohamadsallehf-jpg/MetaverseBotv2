#!/usr/bin/env python3
"""
🎮 MetaverseBot - Enhanced Production Version
ربات متاورس پیشرفته - نسخه بهبود یافته برای پروداکشن

Features:
✅ Auto-reconnect on connection loss
✅ Comprehensive error handling
✅ Health monitoring
✅ Graceful shutdown
✅ Performance optimizations
"""

import asyncio
import sys
import signal
from pathlib import Path
from datetime import datetime
from typing import Optional

from telegram import Update
from telegram.ext import (
    ApplicationBuilder,
    CommandHandler,
    CallbackQueryHandler,
    MessageHandler,
    filters,
    ContextTypes
)
from telegram.error import NetworkError, TimedOut, RetryAfter
from loguru import logger

# Add project root to path
sys.path.insert(0, str(Path(__file__).parent))

from config import settings
from models.base import db_manager
from services.cache import cache
from handlers import user_handlers, admin_handlers, game_handlers, economy_handlers


# Configure enhanced logging
logger.remove()
logger.add(
    sys.stderr,
    format="<green>{time:YYYY-MM-DD HH:mm:ss}</green> | <level>{level: <8}</level> | <cyan>{name}</cyan>:<cyan>{function}</cyan> - <level>{message}</level>",
    level=settings.LOG_LEVEL,
    colorize=True
)
logger.add(
    settings.LOG_FILE,
    format="{time:YYYY-MM-DD HH:mm:ss} | {level: <8} | {name}:{function} - {message}",
    level=settings.LOG_LEVEL,
    rotation="100 MB",
    retention="30 days",
    compression="zip",
    enqueue=True
)


class EnhancedMetaverseBot:
    """Enhanced bot with production-ready features"""
    
    def __init__(self):
        self.app: Optional[ApplicationBuilder] = None
        self.is_running = False
        self.reconnect_attempts = 0
        self.max_reconnect_attempts = 5
        
    async def initialize(self) -> bool:
        """Initialize all components with error handling"""
        try:
            logger.info("🚀 Initializing MetaverseBot...")
            logger.info(f"📝 Environment: {settings.ENVIRONMENT}")
            logger.info(f"🤖 Bot: @{settings.BOT_USERNAME}")
            
            # Initialize database
            logger.info("📊 Connecting to database...")
            await db_manager.init()
            logger.success("✅ Database connected")
            
            # Initialize Redis cache (optional)
            if settings.REDIS_ENABLED:
                logger.info("🔴 Connecting to Redis...")
                try:
                    await cache.connect()
                    if cache.is_connected:
                        logger.success("✅ Redis connected")
                    else:
                        logger.warning("⚠️  Redis not available, running without cache")
                except Exception as e:
                    logger.warning(f"⚠️  Redis connection failed: {e}")
            else:
                logger.info("ℹ️  Redis disabled in config")
            
            # Build application
            logger.info("🤖 Building Telegram application...")
            self.app = (
                ApplicationBuilder()
                .token(settings.BOT_TOKEN)
                .concurrent_updates(True)
                .connection_pool_size(8)
                .read_timeout(30)
                .write_timeout(30)
                .connect_timeout(30)
                .pool_timeout(30)
                .build()
            )
            
            # Register handlers
            self._register_handlers()
            logger.success("✅ Handlers registered")
            
            # Register error handler
            self.app.add_error_handler(self.error_handler)
            logger.success("✅ Error handler registered")
            
            self.is_running = True
            logger.success("🎉 Bot initialization complete!")
            return True
            
        except Exception as e:
            logger.error(f"❌ Initialization failed: {e}")
            logger.exception("Full traceback:")
            return False
    
    def _register_handlers(self):
        """Register all command and callback handlers"""
        
        # User commands
        self.app.add_handler(CommandHandler("start", user_handlers.start_command))
        self.app.add_handler(CommandHandler("help", user_handlers.help_command))
        self.app.add_handler(CommandHandler("info", user_handlers.info_command))
        self.app.add_handler(CommandHandler("profile", user_handlers.profile_command))
        
        # Economy commands
        self.app.add_handler(CommandHandler("coin", economy_handlers.coin_command))
        self.app.add_handler(CommandHandler("balance", economy_handlers.balance_command))
        self.app.add_handler(CommandHandler("daily", economy_handlers.daily_command))
        self.app.add_handler(CommandHandler("transfer", economy_handlers.transfer_command))
        self.app.add_handler(CommandHandler("leaderboard", economy_handlers.leaderboard_command))
        
        # Game commands
        self.app.add_handler(CommandHandler("dice", game_handlers.dice_command))
        self.app.add_handler(CommandHandler("slot", game_handlers.slot_command))
        self.app.add_handler(CommandHandler("coinflip", game_handlers.coinflip_command))
        
        # Admin commands
        self.app.add_handler(CommandHandler("admin", admin_handlers.admin_panel))
        self.app.add_handler(CommandHandler("stats", admin_handlers.stats_command))
        self.app.add_handler(CommandHandler("broadcast", admin_handlers.broadcast_command))
        
        # Callback handlers
        self.app.add_handler(CallbackQueryHandler(self.handle_callback))
        
        # Message handlers
        self.app.add_handler(MessageHandler(filters.TEXT & ~filters.COMMAND, self.handle_message))
        
        logger.info("📋 All handlers registered successfully")
    
    async def handle_callback(self, update: Update, context: ContextTypes.DEFAULT_TYPE):
        """Handle all inline keyboard callbacks"""
        query = update.callback_query
        await query.answer()
        
        data = query.data
        
        try:
            # Route to appropriate handler
            if data.startswith("game_"):
                await game_handlers.handle_game_callback(update, context)
            elif data.startswith("eco_"):
                await economy_handlers.handle_economy_callback(update, context)
            elif data.startswith("admin_"):
                await admin_handlers.handle_admin_callback(update, context)
            else:
                await user_handlers.handle_user_callback(update, context)
                
        except Exception as e:
            logger.error(f"Error in callback handler: {e}")
            await query.edit_message_text("❌ خطایی رخ داد. لطفاً دوباره تلاش کنید.")
    
    async def handle_message(self, update: Update, context: ContextTypes.DEFAULT_TYPE):
        """Handle text messages"""
        try:
            # Check if user is in required channel
            if not await user_handlers.check_membership(update, context):
                return
            
            # Process message
            await user_handlers.process_message(update, context)
            
        except Exception as e:
            logger.error(f"Error in message handler: {e}")
    
    async def error_handler(self, update: Optional[Update], context: ContextTypes.DEFAULT_TYPE):
        """Enhanced error handler with logging and recovery"""
        error = context.error
        
        logger.error(f"⚠️  Exception while handling update: {error}")
        
        if update:
            logger.error(f"Update: {update}")
        
        # Handle specific errors
        if isinstance(error, NetworkError):
            logger.warning("🌐 Network error detected, will retry...")
            self.reconnect_attempts += 1
            if self.reconnect_attempts < self.max_reconnect_attempts:
                await asyncio.sleep(5)
                return
        
        elif isinstance(error, TimedOut):
            logger.warning("⏱️  Timeout error, continuing...")
            return
        
        elif isinstance(error, RetryAfter):
            retry_after = error.retry_after
            logger.warning(f"⏳ Rate limited, waiting {retry_after} seconds...")
            await asyncio.sleep(retry_after)
            return
        
        # Log full traceback for unexpected errors
        logger.exception("Full error traceback:")
        
        # Try to notify user
        if update and update.effective_message:
            try:
                await update.effective_message.reply_text(
                    "❌ متأسفانه خطایی رخ داد. لطفاً بعداً تلاش کنید.\n"
                    "در صورت تکرار، با پشتیبانی تماس بگیرید."
                )
            except:
                pass
    
    async def start(self):
        """Start the bot with enhanced error handling"""
        if not await self.initialize():
            logger.error("❌ Failed to initialize bot")
            return False
        
        try:
            logger.info("🚀 Starting bot polling...")
            await self.app.initialize()
            await self.app.start()
            await self.app.updater.start_polling(
                allowed_updates=Update.ALL_TYPES,
                drop_pending_updates=True
            )
            
            logger.success("✅ Bot is now running!")
            logger.info("Press Ctrl+C to stop")
            
            # Keep running
            while self.is_running:
                await asyncio.sleep(1)
                
        except KeyboardInterrupt:
            logger.info("⏹️  Received shutdown signal")
        except Exception as e:
            logger.error(f"❌ Fatal error: {e}")
            logger.exception("Full traceback:")
        finally:
            await self.shutdown()
    
    async def shutdown(self):
        """Graceful shutdown"""
        logger.info("🛑 Shutting down bot...")
        self.is_running = False
        
        try:
            if self.app:
                await self.app.updater.stop()
                await self.app.stop()
                await self.app.shutdown()
            
            # Close database
            await db_manager.close()
            logger.success("✅ Database closed")
            
            # Close cache
            if cache.is_connected:
                await cache.disconnect()
                logger.success("✅ Cache disconnected")
            
            logger.success("👋 Bot shut down successfully")
            
        except Exception as e:
            logger.error(f"Error during shutdown: {e}")


def signal_handler(signum, frame):
    """Handle system signals"""
    logger.info(f"Received signal {signum}")
    raise KeyboardInterrupt


async def main():
    """Main entry point"""
    logger.info("=" * 50)
    logger.info("🎮 MetaverseBot Starting...")
    logger.info(f"⏰ Time: {datetime.now().strftime('%Y-%m-%d %H:%M:%S')}")
    logger.info("=" * 50)
    
    # Register signal handlers
    signal.signal(signal.SIGINT, signal_handler)
    signal.signal(signal.SIGTERM, signal_handler)
    
    # Create and start bot
    bot = EnhancedMetaverseBot()
    await bot.start()


if __name__ == "__main__":
    try:
        asyncio.run(main())
    except KeyboardInterrupt:
        logger.info("👋 Goodbye!")
    except Exception as e:
        logger.critical(f"💥 Critical error: {e}")
        logger.exception("Full traceback:")
        sys.exit(1)
