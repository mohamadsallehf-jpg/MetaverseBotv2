# 🚀 راهنمای نصب روی VPS - گام به گام

این راهنما برای نصب ربات متاورس روی سرورهای مجازی (VPS) نوشته شده است.

## 📋 قبل از شروع

### مشخصات VPS توصیه شده
- CPU: 2 Core
- RAM: 2GB+
- Storage: 20GB+
- OS: Ubuntu 20.04+ یا Debian 11+
- Network: 100Mbps+

### اطلاعات مورد نیاز
- [ ] IP سرور
- [ ] یوزر و پسورد SSH
- [ ] توکن ربات از BotFather
- [ ] آیدی گروه تلگرام
- [ ] یوزرنیم کانال اجباری

---

## گام 1️⃣: اتصال به سرور

### از Windows (با PuTTY):
1. دانلود و نصب [PuTTY](https://www.putty.org/)
2. وارد کردن IP سرور
3. اتصال و ورود با یوزر/پسورد

### از Linux/Mac (با Terminal):
```bash
ssh root@YOUR_SERVER_IP
# یا
ssh user@YOUR_SERVER_IP
```

---

## گام 2️⃣: آماده‌سازی سرور

### آپدیت سیستم
```bash
sudo apt update && sudo apt upgrade -y
```

### نصب ابزارهای اصلی
```bash
sudo apt install -y \
    python3.9 \
    python3-pip \
    python3-venv \
    git \
    screen \
    htop \
    nano
```

### نصب PostgreSQL (توصیه می‌شود)
```bash
sudo apt install -y postgresql postgresql-contrib

# شروع سرویس
sudo systemctl start postgresql
sudo systemctl enable postgresql

# ساخت دیتابیس
sudo -u postgres psql

# در psql:
CREATE DATABASE metaverse_bot;
CREATE USER bot_user WITH PASSWORD 'رمز_قوی_خودتان';
GRANT ALL PRIVILEGES ON DATABASE metaverse_bot TO bot_user;
\q
```

### نصب Redis (توصیه می‌شود)
```bash
sudo apt install -y redis-server

# شروع سرویس
sudo systemctl start redis
sudo systemctl enable redis

# تست
redis-cli ping
# باید "PONG" برگرداند
```

---

## گام 3️⃣: دانلود و نصب ربات

### دانلود کد
```bash
# رفتن به home directory
cd ~

# کلون ریپو (یا آپلود فایل ZIP)
git clone https://github.com/yourusername/metaverse-bot.git
# یا اگر فایل ZIP دارید:
# unzip metaverse-bot.zip

cd metaverse-bot
```

### اجرای اسکریپت نصب
```bash
chmod +x setup.sh
./setup.sh
```

این اسکریپت:
- ✅ محیط مجازی Python می‌سازد
- ✅ وابستگی‌ها را نصب می‌کند
- ✅ پوشه‌های لازم را می‌سازد
- ✅ فایل .env را کپی می‌کند

---

## گام 4️⃣: تنظیم ربات

### دریافت توکن ربات
1. به [@BotFather](https://t.me/BotFather) بروید
2. `/newbot` بزنید
3. نام ربات را وارد کنید (مثلاً: My Metaverse Bot)
4. یوزرنیم ربات را وارد کنید (باید به bot ختم شود، مثلاً: MyMetaverseBot)
5. توکن را کپی کنید (مثل: `1234567890:ABCdefGHIjklMNOpqrsTUVwxyz`)

### دریافت آیدی گروه
1. ربات را به گروه خود اضافه کنید
2. ربات را ادمین گروه کنید
3. به [@userinfobot](https://t.me/userinfobot) بروید
4. یک پیام در گروه بفرستید
5. پیام را به userinfobot فوروارد کنید
6. آیدی گروه را کپی کنید (مثل: `-1001234567890`)

### دریافت آیدی شخصی
1. به [@userinfobot](https://t.me/userinfobot) پیام `/start` بدهید
2. آیدی شخصی خود را کپی کنید (مثل: `123456789`)

### ویرایش فایل .env
```bash
nano .env
```

محتوای ضروری:
```env
# توکن ربات (از BotFather)
BOT_TOKEN=1234567890:ABCdefGHIjklMNOpqrsTUVwxyz

# آیدی گروه (با منفی)
MAIN_GROUP_ID=-1001234567890

# کانال اجباری (با @)
REQUIRED_CHANNEL=@your_channel

# آیدی مالک (آیدی تلگرام شما)
OWNER_IDS=123456789

# آیدی ادمین‌ها (با کاما جدا کنید)
ADMIN_IDS=987654321,456789123

# دیتابیس PostgreSQL
DATABASE_URL=postgresql+asyncpg://bot_user:رمز_شما@localhost/metaverse_bot

# یا اگر SQLite می‌خواهید:
# DATABASE_URL=sqlite+aiosqlite:///./metaverse_bot.db

# Redis
REDIS_HOST=localhost
REDIS_PORT=6379
REDIS_ENABLED=true

# کلید امنیتی (حداقل 32 کاراکتر)
SECRET_KEY=your-super-secret-key-must-be-at-least-32-characters-long
JWT_SECRET=another-secret-key-for-jwt-tokens-here
ENCRYPTION_KEY=32-characters-encryption-key!!
```

برای ذخیره: `Ctrl + O` سپس `Enter`، برای خروج: `Ctrl + X`

### تنظیم کانال اجباری
1. کانال خود را بسازید
2. ربات را به کانال اضافه و ادمین کنید
3. یوزرنیم کانال را با @ در `.env` وارد کنید

---

## گام 5️⃣: اجرای ربات

### روش 1: اجرای مستقیم (برای تست)
```bash
# فعال کردن محیط مجازی
source venv/bin/activate

# اجرا
python main.py
```

برای توقف: `Ctrl + C`

### روش 2: اجرا با Screen (توصیه می‌شود)
```bash
# ساخت session جدید
screen -S metaverse-bot

# فعال کردن محیط مجازی
source venv/bin/activate

# اجرا
python main.py
```

برای detach (خروج بدون بستن ربات):
- `Ctrl + A` سپس `D`

برای attach مجدد:
```bash
screen -r metaverse-bot
```

### روش 3: اجرا با nohup
```bash
source venv/bin/activate
nohup python main.py > bot.log 2>&1 &

# مشاهده لاگ
tail -f bot.log
```

### روش 4: اجرا با systemd (حرفه‌ای)
```bash
sudo nano /etc/systemd/system/metaverse-bot.service
```

محتوا:
```ini
[Unit]
Description=Metaverse Bot
After=network.target postgresql.service redis.service

[Service]
Type=simple
User=YOUR_USERNAME
WorkingDirectory=/home/YOUR_USERNAME/metaverse-bot
Environment="PATH=/home/YOUR_USERNAME/metaverse-bot/venv/bin"
ExecStart=/home/YOUR_USERNAME/metaverse-bot/venv/bin/python main.py
Restart=always
RestartSec=10

[Install]
WantedBy=multi-user.target
```

جایگزین کنید:
- `YOUR_USERNAME` با یوزرنیم لینوکس خود

فعال‌سازی:
```bash
sudo systemctl daemon-reload
sudo systemctl start metaverse-bot
sudo systemctl enable metaverse-bot

# بررسی وضعیت
sudo systemctl status metaverse-bot

# مشاهده لاگ
sudo journalctl -u metaverse-bot -f
```

---

## گام 6️⃣: تست ربات

1. به گروه تلگرام بروید
2. دستور `/start` را بزنید
3. اگر ربات پاسخ داد، نصب موفق بوده! 🎉

---

## 🔧 دستورات مفید

### مدیریت ربات
```bash
# مشاهده لاگ
tail -f logs/bot.log

# استارت/استاپ با systemd
sudo systemctl start metaverse-bot
sudo systemctl stop metaverse-bot
sudo systemctl restart metaverse-bot

# بررسی فرآیند
ps aux | grep python

# Kill کردن ربات
pkill -f "python main.py"
```

### مدیریت دیتابیس
```bash
# ورود به PostgreSQL
sudo -u postgres psql metaverse_bot

# بکاپ
pg_dump -U bot_user metaverse_bot > backup.sql

# ریستور
psql -U bot_user metaverse_bot < backup.sql
```

### مانیتورینگ
```bash
# CPU و RAM
htop

# دیسک
df -h

# نت‌ورک
iftop
```

---

## 🔥 نکات مهم امنیتی

### 1. تغییر پورت SSH (توصیه می‌شود)
```bash
sudo nano /etc/ssh/sshd_config

# تغییر خط:
# Port 22
# به:
Port 2222

sudo systemctl restart sshd
```

### 2. نصب Fail2Ban (جلوگیری از حملات)
```bash
sudo apt install -y fail2ban
sudo systemctl start fail2ban
sudo systemctl enable fail2ban
```

### 3. فایروال
```bash
# نصب UFW
sudo apt install -y ufw

# اجازه SSH
sudo ufw allow 22/tcp
# یا اگر پورت SSH را عوض کردید:
# sudo ufw allow 2222/tcp

# فعال‌سازی
sudo ufw enable
```

### 4. آپدیت منظم
```bash
# هر هفته یکبار
sudo apt update && sudo apt upgrade -y
```

---

## 🐛 حل مشکلات رایج

### ربات استارت نمی‌شود

**خطا:** `ModuleNotFoundError`
```bash
# نصب مجدد وابستگی‌ها
source venv/bin/activate
pip install -r requirements.txt
```

**خطا:** `Invalid token`
```bash
# بررسی توکن در .env
cat .env | grep BOT_TOKEN
```

### دیتابیس خطا می‌دهد

**خطا:** `Connection refused`
```bash
# بررسی وضعیت PostgreSQL
sudo systemctl status postgresql

# استارت اگر خاموش است
sudo systemctl start postgresql
```

**خطا:** `Authentication failed`
```bash
# ریست پسورد PostgreSQL
sudo -u postgres psql
ALTER USER bot_user WITH PASSWORD 'new_password';
\q

# آپدیت .env
nano .env
```

### Redis خطا می‌دهد

```bash
# بررسی وضعیت
sudo systemctl status redis

# استارت
sudo systemctl start redis

# تست
redis-cli ping
```

### حافظه پر شده

```bash
# پاک کردن لاگ‌های قدیمی
find logs/ -name "*.log" -mtime +30 -delete

# پاک کردن بکاپ‌های قدیمی
find backups/ -name "*.sql" -mtime +30 -delete
```

---

## 📊 مانیتورینگ و بهینه‌سازی

### نصب ابزار مانیتورینگ
```bash
# Glances - مانیتورینگ جامع
sudo apt install -y glances
glances
```

### تنظیم لاگ rotation
```bash
sudo nano /etc/logrotate.d/metaverse-bot
```

محتوا:
```
/home/YOUR_USERNAME/metaverse-bot/logs/*.log {
    daily
    rotate 30
    compress
    delaycompress
    missingok
    notifempty
}
```

### کرون برای بکاپ خودکار
```bash
crontab -e
```

اضافه کنید:
```
# بکاپ روزانه ساعت 3 صبح
0 3 * * * cd /home/YOUR_USERNAME/metaverse-bot && pg_dump -U bot_user metaverse_bot > backups/backup_$(date +\%Y\%m\%d).sql
```

---

## 🎉 تمام!

ربات شما اکنون در حال کار است! 

### چک‌لیست نهایی:
- [ ] ربات در گروه فعال است
- [ ] دستور /start جواب می‌دهد
- [ ] جوین چک کار می‌کند
- [ ] دستورات اقتصادی کار می‌کنند
- [ ] بازی‌ها کار می‌کنند
- [ ] دستورات ادمین کار می‌کنند

### منابع بیشتر:
- 📖 [README.md](README.md) - مستندات کامل
- 🐛 [GitHub Issues](https://github.com/yourusername/metaverse-bot/issues)
- 💬 کانال پشتیبانی: @your_support

---

**نکته:** این ربات را با عشق ساخته شده! اگر مشکلی داشتید، از ما بپرسید! 💙
