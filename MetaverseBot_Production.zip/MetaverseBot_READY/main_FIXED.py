"""
🎮 Advanced Metaverse Bot - Main Entry Point (FIXED VERSION)
ربات متاورس پیشرفته با تمام امکانات - نسخه اصلاح شده

تغییرات نسخه جدید:
- ✅ Callback handler کامل شده
- ✅ Message handler پاسخگو شده
- ✅ تمام دکمه‌های شیشه‌ای کار می‌کنند
"""

import asyncio
import sys
import random
from telegram import Update, InlineKeyboardButton, InlineKeyboardMarkup
from telegram.ext import (
    ApplicationBuilder,
    CommandHandler,
    CallbackQueryHandler,
    MessageHandler,
    filters,
    ContextTypes
)
from telegram.constants import ParseMode
from loguru import logger
from config import settings
from models.base import db_manager
from services.cache import cache
from middlewares.security import security
from handlers import user_handlers, admin_handlers, game_handlers, economy_handlers

# Configure logging
logger.remove()
logger.add(
    sys.stderr,
    format=settings.LOG_FORMAT,
    level=settings.LOG_LEVEL,
    colorize=True
)
logger.add(
    settings.LOG_FILE,
    format=settings.LOG_FORMAT,
    level=settings.LOG_LEVEL,
    rotation=settings.LOG_ROTATION,
    retention=settings.LOG_RETENTION,
    compression="zip"
)


class MetaverseBot:
    """Main bot application"""
    
    def __init__(self):
        self.app = None
    
    async def initialize(self):
        """Initialize all components"""
        logger.info("🚀 Starting Metaverse Bot...")
        
        # Initialize database
        logger.info("📊 Initializing database...")
        await db_manager.init()
        logger.success("✅ Database initialized")
        
        # Initialize Redis cache
        logger.info("🔴 Connecting to Redis...")
        await cache.connect()
        if cache.is_connected:
            logger.success("✅ Redis connected")
        else:
            logger.warning("⚠️ Redis not available, running without cache")
        
        # Build application
        logger.info("🤖 Building bot application...")
        self.app = (
            ApplicationBuilder()
            .token(settings.BOT_TOKEN)
            .concurrent_updates(True)
            .build()
        )
        
        # Register handlers
        self._register_handlers()
        logger.success("✅ Handlers registered")
        
        # Register error handler
        self.app.add_error_handler(self.error_handler)
        
        logger.success("🎉 Bot initialization complete!")
    
    def _register_handlers(self):
        """Register all command and callback handlers"""
        
        # User commands
        self.app.add_handler(CommandHandler("start", user_handlers.start_command))
        self.app.add_handler(CommandHandler("help", user_handlers.help_command))
        self.app.add_handler(CommandHandler("info", user_handlers.info_command))
        self.app.add_handler(CommandHandler("profile", user_handlers.profile_command))
        
        # Economy commands
        self.app.add_handler(CommandHandler("coin", economy_handlers.coin_command))
        self.app.add_handler(CommandHandler("work", economy_handlers.work_command))
        self.app.add_handler(CommandHandler("pay", economy_handlers.pay_command))
        self.app.add_handler(CommandHandler("transfer", economy_handlers.bank_deposit_command))
        self.app.add_handler(CommandHandler("withdraw", economy_handlers.bank_withdraw_command))
        self.app.add_handler(CommandHandler("daily", economy_handlers.daily_reward_command))
        
        # Market commands
        self.app.add_handler(CommandHandler("market", economy_handlers.market_command))
        self.app.add_handler(CommandHandler("guns", economy_handlers.guns_list_command))
        self.app.add_handler(CommandHandler("buygun", economy_handlers.buy_gun_command))
        self.app.add_handler(CommandHandler("buyusd", economy_handlers.buy_usd_command))
        self.app.add_handler(CommandHandler("sellusd", economy_handlers.sell_usd_command))
        
        # Game commands
        self.app.add_handler(CommandHandler("bet", game_handlers.bet_command))
        self.app.add_handler(CommandHandler("slot", game_handlers.slot_command))
        self.app.add_handler(CommandHandler("dice", game_handlers.dice_command))
        self.app.add_handler(CommandHandler("tas", game_handlers.dice_command))  # Alias
        
        # Job commands
        self.app.add_handler(CommandHandler("jobs", user_handlers.jobs_command))
        self.app.add_handler(CommandHandler("setjob", user_handlers.setjob_command))
        
        # Admin commands
        self.app.add_handler(CommandHandler("admin", admin_handlers.admin_panel))
        self.app.add_handler(CommandHandler("ban", admin_handlers.ban_user))
        self.app.add_handler(CommandHandler("mute", admin_handlers.mute_user))
        self.app.add_handler(CommandHandler("stats", admin_handlers.stats_command))
        self.app.add_handler(CommandHandler("givevip", admin_handlers.give_vip_command))
        self.app.add_handler(CommandHandler("removevip", admin_handlers.remove_vip_command))
        self.app.add_handler(CommandHandler("addcoin", admin_handlers.add_coin_command))
        self.app.add_handler(CommandHandler("removecoin", admin_handlers.remove_coin_command))
        
        # Owner commands
        self.app.add_handler(CommandHandler("owner", admin_handlers.owner_panel))
        self.app.add_handler(CommandHandler("backup", admin_handlers.backup_command))
        
        # Leaderboard
        self.app.add_handler(CommandHandler("top", user_handlers.leaderboard_command))
        self.app.add_handler(CommandHandler("topcoin", user_handlers.leaderboard_command))
        
        # Callback query handler
        self.app.add_handler(CallbackQueryHandler(self.callback_handler))
        
        # Message handler for tracking
        self.app.add_handler(
            MessageHandler(filters.TEXT & ~filters.COMMAND, self.message_handler)
        )
    
    async def callback_handler(self, update: Update, context: ContextTypes.DEFAULT_TYPE):
        """
        Handle callback queries
        
        ✅ این هندلر اصلاح شده و کامل است
        ✅ تمام دکمه‌های شیشه‌ای را پردازش می‌کند
        """
        try:
            query = update.callback_query
            await query.answer()
            
            data = query.data
            user_id = query.from_user.id
        except Exception as e:
            logger.error(f"Callback error: {e}")
            return
        
        # ═══════════════════════════════════════════════════════
        # Check membership callback
        # ═══════════════════════════════════════════════════════
        if data == "check_membership":
            is_member = await security.check_channel_membership(context, user_id)
            
            if is_member:
                await query.edit_message_text(
                    "✅ عضویت شما تایید شد! اکنون می‌توانید از ربات استفاده کنید.\n\n"
                    "برای شروع /start را بزنید"
                )
            else:
                await query.answer("❌ هنوز عضو کانال نشده‌اید!", show_alert=True)
        
        # ═══════════════════════════════════════════════════════
        # Main menu callbacks
        # ═══════════════════════════════════════════════════════
        
        # Work menu
        elif data == "work":
            keyboard = [
                [InlineKeyboardButton("💰 کار کردن", callback_data="do_work")],
                [InlineKeyboardButton("💼 لیست مشاغل", callback_data="jobs_list")],
                [InlineKeyboardButton("🔄 تغییر شغل", callback_data="change_job")],
                [InlineKeyboardButton("🔙 بازگشت", callback_data="main_menu")]
            ]
            reply_markup = InlineKeyboardMarkup(keyboard)
            
            await query.edit_message_text(
                "💼 <b>منوی کار</b>\n\n"
                "برای کار کردن و کسب درآمد از دکمه‌های زیر استفاده کنید:",
                parse_mode=ParseMode.HTML,
                reply_markup=reply_markup
            )
        
        # Games menu
        elif data == "games":
            keyboard = [
                [
                    InlineKeyboardButton("🎰 اسلات", callback_data="game_slot"),
                    InlineKeyboardButton("🎲 تاس", callback_data="game_dice")
                ],
                [InlineKeyboardButton("💰 شرط‌بندی", callback_data="game_bet")],
                [InlineKeyboardButton("🔙 بازگشت", callback_data="main_menu")]
            ]
            reply_markup = InlineKeyboardMarkup(keyboard)
            
            await query.edit_message_text(
                "🎮 <b>منوی بازی‌ها</b>\n\n"
                "یک بازی را انتخاب کنید:\n\n"
                "🎰 اسلات - شانس خود را امتحان کنید\n"
                "🎲 تاس - عدد را حدس بزنید\n"
                "💰 شرط‌بندی - شرط ساده",
                parse_mode=ParseMode.HTML,
                reply_markup=reply_markup
            )
        
        # Market menu
        elif data == "market":
            keyboard = [
                [
                    InlineKeyboardButton("🔫 سلاح‌ها", callback_data="market_guns"),
                    InlineKeyboardButton("💵 دلار", callback_data="market_usd")
                ],
                [
                    InlineKeyboardButton("🏠 املاک", callback_data="market_property"),
                    InlineKeyboardButton("🏭 کارخانه", callback_data="market_factory")
                ],
                [InlineKeyboardButton("🔙 بازگشت", callback_data="main_menu")]
            ]
            reply_markup = InlineKeyboardMarkup(keyboard)
            
            await query.edit_message_text(
                "🏪 <b>بازار</b>\n\n"
                "از منوی زیر دسته مورد نظر را انتخاب کنید:",
                parse_mode=ParseMode.HTML,
                reply_markup=reply_markup
            )
        
        # Profile
        elif data == "profile":
            # Show profile inline
            from services.user_service import UserService
            
            async with db_manager.session() as session:
                user_service = UserService(session)
                user = await user_service.get_user(user_id)
                
                if not user:
                    await query.answer("❌ ابتدا /start بزنید", show_alert=True)
                    return
                
                profile_text = f"""
👤 <b>پروفایل</b>

💰 موجودی: {user.balance:,} تومان
🏦 بانک: {user.bank:,} تومان
💎 ثروت کل: {user.total_wealth:,} تومان

📊 سطح: {user.level}
⭐ XP: {user.xp:,} / {user.xp_next:,}

💼 شغل: {user.job_info['name']}
{'💎 VIP: فعال' if user.vip_active else ''}

برای پروفایل کامل: /profile
"""
                
                keyboard = [[InlineKeyboardButton("🔙 بازگشت", callback_data="main_menu")]]
                reply_markup = InlineKeyboardMarkup(keyboard)
                
                await query.edit_message_text(
                    profile_text,
                    parse_mode=ParseMode.HTML,
                    reply_markup=reply_markup
                )
        
        # Leaderboard
        elif data == "leaderboard":
            from services.user_service import UserService
            
            async with db_manager.session() as session:
                user_service = UserService(session)
                top_users = await user_service.get_leaderboard(limit=5)
                
                if not top_users:
                    await query.answer("📊 هنوز کاربری ثبت نشده", show_alert=True)
                    return
                
                leaderboard_text = "🏆 <b>برترین بازیکنان</b>\n\n"
                
                medals = ["🥇", "🥈", "🥉", "4️⃣", "5️⃣"]
                
                for idx, user in enumerate(top_users):
                    medal = medals[idx] if idx < len(medals) else f"{idx+1}."
                    user_display = f"@{user.username}" if user.username else user.first_name
                    wealth = user.total_wealth
                    
                    leaderboard_text += f"{medal} {user_display} - {wealth:,} تومان\n"
                
                leaderboard_text += "\n\nبرای لیست کامل: /top"
                
                keyboard = [[InlineKeyboardButton("🔙 بازگشت", callback_data="main_menu")]]
                reply_markup = InlineKeyboardMarkup(keyboard)
                
                await query.edit_message_text(
                    leaderboard_text,
                    parse_mode=ParseMode.HTML,
                    reply_markup=reply_markup
                )
        
        # Help
        elif data == "help":
            help_text = """
📚 <b>راهنمای سریع</b>

💰 <b>اقتصادی:</b>
/coin - سکه رایگان
/work - کار کردن
/daily - هدیه روزانه

🎮 <b>بازی:</b>
/slot - اسلات
/dice - تاس
/bet - شرط‌بندی

🏪 <b>بازار:</b>
/market - بازار
/guns - سلاح‌ها

برای راهنمای کامل: /help
"""
            
            keyboard = [[InlineKeyboardButton("🔙 بازگشت", callback_data="main_menu")]]
            reply_markup = InlineKeyboardMarkup(keyboard)
            
            await query.edit_message_text(
                help_text,
                parse_mode=ParseMode.HTML,
                reply_markup=reply_markup
            )
        
        # Main menu
        elif data == "main_menu":
            keyboard = [
                [
                    InlineKeyboardButton("💰 کار کردن", callback_data="work"),
                    InlineKeyboardButton("🎮 بازی", callback_data="games")
                ],
                [
                    InlineKeyboardButton("🏪 بازار", callback_data="market"),
                    InlineKeyboardButton("📊 پروفایل", callback_data="profile")
                ],
                [
                    InlineKeyboardButton("📈 رتبه‌بندی", callback_data="leaderboard"),
                    InlineKeyboardButton("❓ راهنما", callback_data="help")
                ]
            ]
            reply_markup = InlineKeyboardMarkup(keyboard)
            
            await query.edit_message_text(
                "🎮 <b>منوی اصلی</b>\n\n"
                "یک گزینه را انتخاب کنید:",
                parse_mode=ParseMode.HTML,
                reply_markup=reply_markup
            )
        
        # ═══════════════════════════════════════════════════════
        # Action callbacks (do work, games, etc.)
        # ═══════════════════════════════════════════════════════
        
        elif data == "do_work":
            await query.answer("برای کار کردن از دستور /work استفاده کنید", show_alert=True)
        
        elif data == "jobs_list":
            await query.answer("برای لیست مشاغل از دستور /jobs استفاده کنید", show_alert=True)
        
        elif data == "change_job":
            await query.answer("برای تغییر شغل: /setjob [نام شغل]", show_alert=True)
        
        elif data.startswith("game_"):
            game_name = data.replace("game_", "")
            await query.answer(
                f"برای بازی {game_name} از دستور /{game_name} [مقدار] استفاده کنید",
                show_alert=True
            )
        
        elif data.startswith("market_"):
            category = data.replace("market_", "")
            await query.answer(
                f"برای خرید از دسته {category} از دستورات مربوطه استفاده کنید.\n"
                "راهنما: /help",
                show_alert=True
            )
    
    async def message_handler(self, update: Update, context: ContextTypes.DEFAULT_TYPE):
        """
        Handle regular messages for activity tracking
        
        ✅ این هندلر اصلاح شده و پاسخگو است
        ✅ به پیام‌های عادی کاربر پاسخ می‌دهد
        """
        
        # Validate update
        if not update.effective_chat or not update.message or not update.message.text:
            return
        
        # فقط در گروه اصلی پاسخ بده
        if not security.is_main_group(update.effective_chat.id):
            return
        
        # دریافت متن پیام
        message_text = update.message.text
        
        # اگر پیام حاوی کلمات کلیدی باشد
        keywords = {
            "سلام": "👋 سلام! خوش اومدی! برای شروع /start بزن",
            "راهنما": "📚 برای راهنمای کامل /help بزن",
            "کمک": "❓ برای کمک /help بزن",
            "پروفایل": "👤 برای مشاهده پروفایل /profile بزن",
            "کار": "💼 برای کار کردن /work بزن",
            "بازی": "🎮 برای بازی‌ها /help بزن",
            "سکه": "💰 برای دریافت سکه /coin بزن",
        }
        
        # چک کردن کلمات کلیدی
        for keyword, response in keywords.items():
            if keyword in message_text:
                await update.message.reply_text(response)
                return
        
        # پاسخ پیش‌فرض
        # فقط گاهی پاسخ بده تا اسپم نشه
        if random.random() < 0.1:  # 10% شانس پاسخ
            await update.message.reply_text(
                "👋 برای استفاده از ربات از دستورات استفاده کن!\n"
                "📚 راهنما: /help"
            )
    
    async def error_handler(self, update: Update, context: ContextTypes.DEFAULT_TYPE):
        """Handle errors"""
        logger.error(f"❌ Error handling update: {context.error}")
        
        try:
            if update and update.effective_message:
                await update.effective_message.reply_text(
                    "⚠️ خطایی رخ داد! لطفاً دوباره تلاش کنید."
                )
        except Exception as e:
            logger.error(f"Error sending error message: {e}")
    
    async def run(self):
        """Run the bot"""
        try:
            await self.initialize()
            logger.info("🤖 Bot is running...")
            await self.app.run_polling(allowed_updates=Update.ALL_TYPES)
        except KeyboardInterrupt:
            logger.info("🛑 Bot stopped by user")
        except Exception as e:
            logger.critical(f"💥 Critical error: {e}")
            raise
        finally:
            await self.shutdown()
    
    async def shutdown(self):
        """Cleanup on shutdown"""
        logger.info("🧹 Shutting down...")
        
        # Close database
        await db_manager.close()
        logger.info("Database closed")
        
        # Close Redis
        await cache.disconnect()
        logger.info("Cache closed")
        
        logger.success("✅ Shutdown complete")


async def main():
    """Main entry point"""
    bot = MetaverseBot()
    await bot.run()


if __name__ == "__main__":
    try:
        asyncio.run(main())
    except KeyboardInterrupt:
        logger.info("👋 Goodbye!")
    except Exception as e:
        logger.critical(f"Fatal error: {e}")
        sys.exit(1)
