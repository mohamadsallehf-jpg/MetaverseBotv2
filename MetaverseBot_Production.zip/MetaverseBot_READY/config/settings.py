"""
🎮 Metaverse Bot - Advanced Configuration System
تنظیمات پیشرفته و کامل ربات متاورس
"""

import os
from typing import List, Optional
from pathlib import Path
from pydantic import Field, validator
from pydantic_settings import BaseSettings
from dotenv import load_dotenv

# Load environment variables
load_dotenv('env')

# Base directory
BASE_DIR = Path(__file__).resolve().parent.parent


class Settings(BaseSettings):
    """تنظیمات اصلی برنامه"""
    
    # ═══════════════════════════════════════════════════════
    # 🤖 Bot Configuration
    # ═══════════════════════════════════════════════════════
    BOT_TOKEN: str = Field(..., description="Telegram Bot Token")
    BOT_USERNAME: str = Field(default="", description="Bot Username")
    
    # ═══════════════════════════════════════════════════════
    # 🔐 Security & Authentication
    # ═══════════════════════════════════════════════════════
    SECRET_KEY: str = Field(..., description="Secret key for encryption")
    JWT_SECRET: str = Field(..., description="JWT secret key")
    ENCRYPTION_KEY: str = Field(..., description="Encryption key")
    
    OWNER_IDS: List[int] = Field(default_factory=list)
    ADMIN_IDS: List[int] = Field(default_factory=list)
    
    @validator('OWNER_IDS', 'ADMIN_IDS', pre=True)
    def parse_ids(cls, v):
        if isinstance(v, str):
            return [int(x.strip()) for x in v.split(',') if x.strip()]
        return v
    
    # ═══════════════════════════════════════════════════════
    # 🏠 Group & Channel Settings
    # ═══════════════════════════════════════════════════════
    MAIN_GROUP_ID: int = Field(..., description="Main group chat ID")
    REQUIRED_CHANNEL: str = Field(..., description="Required channel username")
    ADMIN_CHAT_ID: Optional[int] = Field(default=None, description="Admin notifications chat")
    
    # ═══════════════════════════════════════════════════════
    # 💾 Database Configuration
    # ═══════════════════════════════════════════════════════
    DATABASE_URL: str = Field(
        default="sqlite+aiosqlite:///./metaverse_bot.db",
        description="Database connection URL"
    )
    DATABASE_ECHO: bool = Field(default=False, description="Echo SQL queries")
    DATABASE_POOL_SIZE: int = Field(default=20, description="Database pool size")
    DATABASE_MAX_OVERFLOW: int = Field(default=40, description="Max overflow connections")
    
    # ═══════════════════════════════════════════════════════
    # 🔴 Redis Configuration
    # ═══════════════════════════════════════════════════════
    REDIS_HOST: str = Field(default="localhost")
    REDIS_PORT: int = Field(default=6379)
    REDIS_PASSWORD: Optional[str] = Field(default=None)
    REDIS_DB: int = Field(default=0)
    REDIS_ENABLED: bool = Field(default=True)
    
    @property
    def REDIS_URL(self) -> str:
        """Redis connection URL"""
        if self.REDIS_PASSWORD:
            return f"redis://:{self.REDIS_PASSWORD}@{self.REDIS_HOST}:{self.REDIS_PORT}/{self.REDIS_DB}"
        return f"redis://{self.REDIS_HOST}:{self.REDIS_PORT}/{self.REDIS_DB}"
    
    # ═══════════════════════════════════════════════════════
    # 🚦 Rate Limiting
    # ═══════════════════════════════════════════════════════
    RATE_LIMIT_ENABLED: bool = Field(default=True)
    MAX_REQUESTS_PER_MINUTE: int = Field(default=30)
    MAX_REQUESTS_PER_HOUR: int = Field(default=500)
    MAX_REQUESTS_PER_DAY: int = Field(default=5000)
    
    # Anti-spam settings
    SPAM_THRESHOLD: int = Field(default=10, description="Max messages in spam window")
    SPAM_WINDOW: int = Field(default=5, description="Spam detection window (seconds)")
    AUTO_BAN_ON_SPAM: bool = Field(default=True)
    
    # ═══════════════════════════════════════════════════════
    # 💰 Economy Settings
    # ═══════════════════════════════════════════════════════
    INITIAL_BALANCE: int = Field(default=500000, description="Starting balance")
    INITIAL_BANK: int = Field(default=0, description="Starting bank balance")
    INITIAL_LEVEL: int = Field(default=1)
    INITIAL_XP: int = Field(default=0)
    
    # Currency prices
    USD_PRICE: int = Field(default=83750, description="Dollar price in coins")
    MAX_USD: int = Field(default=400, description="Max USD to buy at once")
    STONE_PRICE: int = Field(default=5000)
    WOOD_PRICE: int = Field(default=3000)
    GOLD_PRICE: int = Field(default=1000000)
    DIAMOND_PRICE: int = Field(default=10000000)
    
    # VIP Settings
    VIP_PRICE: int = Field(default=50000000, description="VIP purchase price")
    VIP_DAILY_BONUS: int = Field(default=100000)
    VIP_WORK_MULTIPLIER: float = Field(default=1.5)
    VIP_GAME_MULTIPLIER: float = Field(default=2.0)
    
    # Daily rewards
    DAILY_REWARD: int = Field(default=100000)
    WEEKLY_REWARD: int = Field(default=1000000)
    MONTHLY_REWARD: int = Field(default=10000000)
    REFERRAL_BONUS: int = Field(default=50000)
    
    # Transaction fees
    TRANSFER_FEE: float = Field(default=0.02, description="2% transfer fee")
    BANK_WITHDRAW_FEE: float = Field(default=0.01, description="1% withdrawal fee")
    
    # ═══════════════════════════════════════════════════════
    # ⏰ Cooldowns (seconds)
    # ═══════════════════════════════════════════════════════
    COOLDOWN_COIN: int = Field(default=300)  # 5 minutes
    COOLDOWN_WORK: int = Field(default=600)  # 10 minutes
    COOLDOWN_BREAK: int = Field(default=3600)  # 1 hour
    COOLDOWN_HAKBANK: int = Field(default=10800)  # 3 hours
    COOLDOWN_CHARITY: int = Field(default=1800)  # 30 minutes
    COOLDOWN_DAILY: int = Field(default=86400)  # 24 hours
    COOLDOWN_SLOT: int = Field(default=300)  # 5 minutes
    COOLDOWN_DICE: int = Field(default=300)  # 5 minutes
    COOLDOWN_JOB_CHANGE: int = Field(default=86400)  # 24 hours
    
    # VIP cooldown reduction
    VIP_COOLDOWN_REDUCTION: float = Field(default=0.5, description="50% reduction")
    
    # ═══════════════════════════════════════════════════════
    # 🎮 Game Settings
    # ═══════════════════════════════════════════════════════
    MIN_BET: int = Field(default=1000, description="Minimum bet amount")
    MAX_BET: int = Field(default=100000000, description="Maximum bet amount")
    
    # Slot machine
    SLOT_JACKPOT_CHANCE: float = Field(default=0.001, description="0.1% jackpot chance")
    SLOT_JACKPOT_MULTIPLIER: int = Field(default=100)
    SLOT_WIN_MULTIPLIER: float = Field(default=2.5)
    
    # Bet game
    BET_WIN_MULTIPLIER: float = Field(default=2.0, description="Bet win multiplier")
    
    # Dice game
    DICE_WIN_MULTIPLIER: float = Field(default=2.0)
    DICE_JACKPOT_NUMBER: int = Field(default=6)
    DICE_JACKPOT_MULTIPLIER: float = Field(default=10.0)
    
    # Challenge settings
    CHALLENGE_MIN_BET: int = Field(default=10000)
    CHALLENGE_MAX_BET: int = Field(default=50000000)
    CHALLENGE_TIMEOUT: int = Field(default=300)  # 5 minutes
    
    # ═══════════════════════════════════════════════════════
    # 🏠 Properties & Factories
    # ═══════════════════════════════════════════════════════
    MAX_HOMES: int = Field(default=15)
    MAX_FACTORIES: int = Field(default=10)
    
    # Tax settings
    BASE_TAX_RATE: float = Field(default=0.1, description="10% base tax")
    HOME_TAX_REDUCTION: float = Field(default=0.02, description="2% per home")
    
    # Factory production rates (per hour)
    STONE_FACTORY_RATE: int = Field(default=10)
    WOOD_FACTORY_RATE: int = Field(default=15)
    GOLD_FACTORY_RATE: int = Field(default=5)
    DIAMOND_FACTORY_RATE: int = Field(default=2)
    
    # ═══════════════════════════════════════════════════════
    # 👮 Security & Anti-Cheat
    # ═══════════════════════════════════════════════════════
    MAX_DAILY_EARNINGS: int = Field(default=1000000000, description="Max earnings per day")
    MAX_BALANCE: int = Field(default=999999999999, description="Maximum balance")
    
    SUSPICIOUS_ACTIVITY_THRESHOLD: int = Field(default=10)
    AUTO_BAN_CHEATERS: bool = Field(default=True)
    
    # Transaction validation
    VALIDATE_TRANSACTIONS: bool = Field(default=True)
    LOG_ALL_TRANSACTIONS: bool = Field(default=True)
    
    # ═══════════════════════════════════════════════════════
    # 📊 Logging & Monitoring
    # ═══════════════════════════════════════════════════════
    LOG_LEVEL: str = Field(default="INFO")
    LOG_FILE: str = Field(default="logs/bot.log")
    LOG_ROTATION: str = Field(default="100 MB")
    LOG_RETENTION: str = Field(default="30 days")
    LOG_FORMAT: str = Field(
        default="<green>{time:YYYY-MM-DD HH:mm:ss}</green> | <level>{level: <8}</level> | <cyan>{name}</cyan>:<cyan>{function}</cyan>:<cyan>{line}</cyan> - <level>{message}</level>"
    )
    
    # Sentry integration
    SENTRY_DSN: Optional[str] = Field(default=None)
    SENTRY_ENABLED: bool = Field(default=False)
    
    # ═══════════════════════════════════════════════════════
    # 🌐 Web Panel & API
    # ═══════════════════════════════════════════════════════
    ENABLE_WEB_PANEL: bool = Field(default=True)
    WEB_PANEL_HOST: str = Field(default="0.0.0.0")
    WEB_PANEL_PORT: int = Field(default=8000)
    WEB_PANEL_SECRET: str = Field(default="change-this-secret")
    
    # API settings
    API_ENABLED: bool = Field(default=True)
    API_KEY_EXPIRY: int = Field(default=86400)  # 24 hours
    
    # ═══════════════════════════════════════════════════════
    # 🔔 Notifications & Alerts
    # ═══════════════════════════════════════════════════════
    ENABLE_NOTIFICATIONS: bool = Field(default=True)
    NOTIFY_ADMINS_ON_ERROR: bool = Field(default=True)
    NOTIFY_ON_NEW_USER: bool = Field(default=True)
    NOTIFY_ON_LARGE_TRANSACTION: bool = Field(default=True)
    LARGE_TRANSACTION_THRESHOLD: int = Field(default=100000000)
    
    # ═══════════════════════════════════════════════════════
    # 💾 Backup Settings
    # ═══════════════════════════════════════════════════════
    ENABLE_BACKUP: bool = Field(default=True)
    BACKUP_INTERVAL: int = Field(default=3600, description="Backup every hour")
    BACKUP_RETENTION_DAYS: int = Field(default=30)
    BACKUP_PATH: str = Field(default="backups")
    
    # ═══════════════════════════════════════════════════════
    # 📈 Statistics & Analytics
    # ═══════════════════════════════════════════════════════
    ENABLE_STATISTICS: bool = Field(default=True)
    STATISTICS_UPDATE_INTERVAL: int = Field(default=300)  # 5 minutes
    TRACK_USER_ACTIVITY: bool = Field(default=True)
    
    # Leaderboard settings
    LEADERBOARD_TOP_COUNT: int = Field(default=10)
    LEADERBOARD_UPDATE_INTERVAL: int = Field(default=600)  # 10 minutes
    
    # ═══════════════════════════════════════════════════════
    # 🎨 UI & UX Settings
    # ═══════════════════════════════════════════════════════
    USE_GLASS_BUTTONS: bool = Field(default=True, description="دکمه‌های شیشه‌ای")
    LANGUAGE: str = Field(default="fa", description="Bot language")
    TIMEZONE: str = Field(default="Asia/Tehran")
    
    # Message settings
    DELETE_COMMAND_MESSAGES: bool = Field(default=False)
    COMMAND_DELETE_DELAY: int = Field(default=5)
    
    # Tutorial
    ENABLE_TUTORIAL: bool = Field(default=True)
    FORCE_TUTORIAL: bool = Field(default=False)
    
    # ═══════════════════════════════════════════════════════
    # 🎁 Events & Promotions
    # ═══════════════════════════════════════════════════════
    ENABLE_EVENTS: bool = Field(default=True)
    EVENT_MULTIPLIER: float = Field(default=2.0)
    
    # Special dates
    ENABLE_HOLIDAY_BONUSES: bool = Field(default=True)
    
    # ═══════════════════════════════════════════════════════
    # 🔧 Advanced Features
    # ═══════════════════════════════════════════════════════
    # Caching
    ENABLE_CACHE: bool = Field(default=True)
    CACHE_TTL: int = Field(default=300)  # 5 minutes
    
    # Task queue
    ENABLE_TASK_QUEUE: bool = Field(default=True)
    CELERY_BROKER_URL: Optional[str] = Field(default=None)
    
    # Machine Learning
    ENABLE_ML_FEATURES: bool = Field(default=False)
    ML_FRAUD_DETECTION: bool = Field(default=False)
    
    # ═══════════════════════════════════════════════════════
    # 🌍 Paths
    # ═══════════════════════════════════════════════════════
    @property
    def DATA_DIR(self) -> Path:
        return BASE_DIR / "data"
    
    @property
    def LOGS_DIR(self) -> Path:
        return BASE_DIR / "logs"
    
    @property
    def ASSETS_DIR(self) -> Path:
        return BASE_DIR / "assets"
    
    @property
    def BACKUP_DIR(self) -> Path:
        return BASE_DIR / self.BACKUP_PATH
    
    @property
    def TEMP_DIR(self) -> Path:
        return BASE_DIR / "temp"
    
    class Config:
        env_file = ".env"
        case_sensitive = True
        extra = "ignore"


# ═══════════════════════════════════════════════════════
# 🎮 Game Configuration Classes
# ═══════════════════════════════════════════════════════

class JobConfig:
    """تنظیمات مشاغل"""
    
    JOBS = {
        "geda": {
            "name": "🤲 گدا",
            "base_salary": 5000,
            "description": "شغل پایه - با شانس زندگی کن!",
            "required_level": 1,
            "vip_required": False,
            "special_ability": "chance_bonus"
        },
        "worker": {
            "name": "👷 کارگر",
            "base_salary": 15000,
            "description": "کار سخت، درآمد متوسط",
            "required_level": 2,
            "vip_required": False,
        },
        "farmer": {
            "name": "👨‍🌾 کشاورز",
            "base_salary": 25000,
            "description": "کشت و برداشت محصولات",
            "required_level": 5,
            "vip_required": False,
            "special_ability": "material_bonus"
        },
        "trader": {
            "name": "💼 تاجر",
            "base_salary": 40000,
            "description": "خرید و فروش کالا",
            "required_level": 10,
            "vip_required": False,
            "special_ability": "price_discount"
        },
        "engineer": {
            "name": "👨‍🔧 مهندس",
            "base_salary": 60000,
            "description": "طراحی و ساخت",
            "required_level": 15,
            "vip_required": False,
            "special_ability": "factory_boost"
        },
        "doctor": {
            "name": "👨‍⚕️ دکتر",
            "base_salary": 100000,
            "description": "درمان و درآمد بالا",
            "required_level": 20,
            "vip_required": False,
            "special_ability": "health_bonus"
        },
        "police": {
            "name": "👮 پلیس",
            "base_salary": 80000,
            "description": "حفظ نظم و امنیت",
            "required_level": 25,
            "vip_required": False,
            "special_ability": "catch_thieves"
        },
        "hacker": {
            "name": "💻 هکر",
            "base_salary": 150000,
            "description": "نفوذ به سیستم‌ها",
            "required_level": 30,
            "vip_required": True,
            "special_ability": "bank_hack"
        },
        "businessman": {
            "name": "🤵 کسب‌وکار",
            "base_salary": 200000,
            "description": "مدیریت شرکت",
            "required_level": 40,
            "vip_required": True,
            "special_ability": "passive_income"
        },
        "celebrity": {
            "name": "🌟 سلبریتی",
            "base_salary": 300000,
            "description": "محبوبیت جهانی",
            "required_level": 50,
            "vip_required": True,
            "special_ability": "fame_bonus"
        }
    }


class WeaponConfig:
    """تنظیمات سلاح‌ها"""
    
    WEAPONS = {
        # Cold Weapons (سلاح‌های سرد)
        "whip": {"name": "شلاق", "price": 0, "power": 9.3, "category": "cold"},
        "boxing_claw": {"name": "پنجه بوکس", "price": 1000000, "power": 9.4, "category": "cold"},
        "knife": {"name": "چاقو", "price": 3000000, "power": 9.5, "category": "cold"},
        "club": {"name": "چماق", "price": 5000000, "power": 9.6, "category": "cold"},
        "baton": {"name": "باتون", "price": 6000000, "power": 9.7, "category": "cold"},
        "dagger": {"name": "دشنه", "price": 8000000, "power": 9.8, "category": "cold"},
        "spear": {"name": "نیزه", "price": 13000000, "power": 9.9, "category": "cold"},
        "nunchaku": {"name": "نانچیکو", "price": 17000000, "power": 10.0, "category": "cold"},
        "khonjar": {"name": "خنجر", "price": 26000000, "power": 10.1, "category": "cold"},
        "axe": {"name": "تبر", "price": 32000000, "power": 10.2, "category": "cold"},
        "bow": {"name": "تیر و کمان", "price": 37000000, "power": 10.3, "category": "cold"},
        "sword": {"name": "شمشیر", "price": 49000000, "power": 10.4, "category": "cold"},
        "gorz": {"name": "گرز", "price": 63000000, "power": 10.5, "category": "cold"},
        "katana": {"name": "کاتانا", "price": 75000000, "power": 10.6, "category": "cold"},
        "shuriken": {"name": "شوریکن", "price": 110000000, "power": 10.7, "category": "cold"},
        "double_sword": {"name": "شمشیر دولبه", "price": 150000000, "power": 10.8, "category": "cold"},
        
        # Light Firearms (سلاح‌های گرم سبک)
        "grenade": {"name": "نارنجک", "price": 200000000, "power": 20.0, "category": "light"},
        "mp5": {"name": "ام پی5", "price": 250000000, "power": 20.1, "category": "light"},
        "pistol": {"name": "تپانچه", "price": 300000000, "power": 20.2, "category": "light"},
        "colt": {"name": "کلت", "price": 350000000, "power": 20.3, "category": "light"},
        "shotgun": {"name": "تفنگ شکاری", "price": 400000000, "power": 20.4, "category": "light"},
        "uzi": {"name": "اوزی", "price": 450000000, "power": 20.5, "category": "light"},
        "m16": {"name": "ام 16", "price": 500000000, "power": 20.6, "category": "light"},
        "ak47": {"name": "کلاشینکف", "price": 600000000, "power": 20.7, "category": "light"},
        
        # Heavy Firearms (سلاح‌های گرم سنگین)
        "sniper": {"name": "اسنایپر", "price": 700000000, "power": 30.0, "category": "heavy"},
        "rpg": {"name": "آر پی جی", "price": 800000000, "power": 30.2, "category": "heavy"},
        "minigun": {"name": "مینی گان", "price": 900000000, "power": 30.4, "category": "heavy"},
        "tank": {"name": "تانک", "price": 1500000000, "power": 40.0, "category": "heavy"},
        "missile": {"name": "موشک", "price": 2000000000, "power": 45.0, "category": "heavy"},
        "fighter_jet": {"name": "جت جنگنده", "price": 3000000000, "power": 50.0, "category": "heavy"},
        
        # Mass Destruction (سلاح‌های کشتار جمعی)
        "atomic_bomb": {"name": "بمب اتمی", "price": 5000000000, "power": 100.0, "category": "mass"},
        "hydrogen_bomb": {"name": "بمب هیدروژنی", "price": 7000000000, "power": 120.0, "category": "mass"},
        
        # Modern Weapons (سلاح‌های مدرن)
        "laser_gun": {"name": "تفنگ لیزری", "price": 10000000000, "power": 150.0, "category": "modern"},
        "plasma_cannon": {"name": "توپ پلاسما", "price": 15000000000, "power": 200.0, "category": "modern"},
        "quantum_bomb": {"name": "بمب کوانتومی", "price": 25000000000, "power": 300.0, "category": "modern"},
    }


class PropertyConfig:
    """تنظیمات املاک و کارخانه‌ها"""
    
    PROPERTIES = {
        "home_small": {
            "name": "🏠 خانه کوچک",
            "base_price": 20000000,
            "price_increase": 10000000,
            "tax_reduction": 0.02,
            "description": "کاهش 2% مالیات"
        },
        "home_medium": {
            "name": "🏡 خانه متوسط",
            "base_price": 50000000,
            "price_increase": 25000000,
            "tax_reduction": 0.05,
            "description": "کاهش 5% مالیات"
        },
        "home_large": {
            "name": "🏰 خانه بزرگ",
            "base_price": 150000000,
            "price_increase": 50000000,
            "tax_reduction": 0.10,
            "description": "کاهش 10% مالیات"
        },
        "mansion": {
            "name": "🏛️ عمارت",
            "base_price": 500000000,
            "price_increase": 100000000,
            "tax_reduction": 0.20,
            "description": "کاهش 20% مالیات"
        }
    }
    
    FACTORIES = {
        "stone_factory": {
            "name": "⛏️ کارخانه سنگ",
            "price": 50000000,
            "production_rate": 10,
            "production_item": "stone",
            "description": "تولید 10 سنگ در ساعت"
        },
        "wood_factory": {
            "name": "🪵 کارخانه چوب",
            "price": 40000000,
            "production_rate": 15,
            "production_item": "wood",
            "description": "تولید 15 چوب در ساعت"
        },
        "gold_mine": {
            "name": "⚜️ معدن طلا",
            "price": 200000000,
            "production_rate": 5,
            "production_item": "gold",
            "description": "تولید 5 طلا در ساعت"
        },
        "diamond_mine": {
            "name": "💎 معدن الماس",
            "price": 500000000,
            "production_rate": 2,
            "production_item": "diamond",
            "description": "تولید 2 الماس در ساعت"
        }
    }


# Create singleton instance
settings = Settings()

# Ensure directories exist
for directory in [
    settings.DATA_DIR,
    settings.LOGS_DIR,
    settings.ASSETS_DIR,
    settings.BACKUP_DIR,
    settings.TEMP_DIR
]:
    directory.mkdir(parents=True, exist_ok=True)
