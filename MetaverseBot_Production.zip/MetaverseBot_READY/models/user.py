"""
User model with all gaming features
"""

from datetime import datetime, timedelta
from typing import Optional, List, Dict, Any, Tuple
from sqlalchemy import Column, BigInteger, String, Integer, Boolean, Float, DateTime, JSON, Text, Index
from sqlalchemy.orm import relationship
from models.base import Base, TimestampMixin
from config import settings, JobConfig
import secrets
import string


class User(Base, TimestampMixin):
    """User model - کاربران بازی"""
    
    __tablename__ = "users"
    
    # Primary Key
    user_id = Column(BigInteger, primary_key=True, index=True)
    
    # Basic Info
    username = Column(String(255), nullable=True, index=True)
    first_name = Column(String(255), nullable=False)
    last_name = Column(String(255), nullable=True)
    full_name = Column(String(511), nullable=False)
    language_code = Column(String(10), default="fa")
    
    # Security
    secret_code = Column(String(20), unique=True, index=True, nullable=False)
    is_banned = Column(Boolean, default=False, index=True)
    ban_reason = Column(Text, nullable=True)
    ban_expire = Column(DateTime, nullable=True)
    is_muted = Column(Boolean, default=False)
    mute_expire = Column(DateTime, nullable=True)
    warnings = Column(Integer, default=0)
    
    # Authentication
    api_key = Column(String(255), nullable=True, unique=True)
    api_key_expire = Column(DateTime, nullable=True)
    
    # Status
    is_active = Column(Boolean, default=True, index=True)
    is_online = Column(Boolean, default=False)
    last_seen = Column(DateTime, default=datetime.utcnow)
    last_activity = Column(DateTime, default=datetime.utcnow, index=True)
    
    # Economy - Main Balance
    balance = Column(BigInteger, default=settings.INITIAL_BALANCE, nullable=False)
    bank = Column(BigInteger, default=settings.INITIAL_BANK, nullable=False)
    
    # Resources
    stone = Column(Integer, default=0)
    wood = Column(Integer, default=0)
    gold = Column(Integer, default=0)
    diamond = Column(Integer, default=0)
    usd = Column(Integer, default=0)
    
    # Special Items
    energy = Column(Integer, default=100)  # انرژی برای کارها
    health = Column(Integer, default=100)  # سلامتی
    hunger = Column(Integer, default=100)  # گرسنگی
    
    # Level & Experience
    level = Column(Integer, default=settings.INITIAL_LEVEL, index=True)
    xp = Column(BigInteger, default=settings.INITIAL_XP)
    xp_next = Column(BigInteger, default=1000)
    total_xp = Column(BigInteger, default=0)
    
    # Job System
    job = Column(String(50), default="geda", index=True)
    job_experience = Column(Integer, default=0)
    job_level = Column(Integer, default=1)
    last_job_change = Column(DateTime, nullable=True)
    
    # VIP System
    is_vip = Column(Boolean, default=False, index=True)
    vip_expire = Column(DateTime, nullable=True)
    vip_level = Column(Integer, default=0)  # 0: Normal, 1: VIP, 2: VIP+, 3: VIP++
    account_type = Column(String(50), default="کاربر معمولی")
    
    # Properties & Assets
    properties = Column(JSON, default=dict)  # {property_type: count}
    factories = Column(JSON, default=dict)  # {factory_type: count}
    workers = Column(Integer, default=0)
    
    # Weapons
    weapons = Column(JSON, default=lambda: ["whip"])  # List of owned weapons
    current_weapon = Column(String(50), default="whip")
    weapon_experience = Column(Integer, default=0)
    
    # Statistics - Gaming
    total_games = Column(Integer, default=0)
    wins = Column(Integer, default=0, index=True)
    losses = Column(Integer, default=0)
    win_rate = Column(Float, default=0.0)
    win_streak = Column(Integer, default=0)
    max_win_streak = Column(Integer, default=0)
    
    # Statistics - Economy
    total_earned = Column(BigInteger, default=0, index=True)
    total_spent = Column(BigInteger, default=0)
    total_donated = Column(BigInteger, default=0)
    total_received = Column(BigInteger, default=0)
    total_tax_paid = Column(BigInteger, default=0)
    
    # Statistics - Activity
    total_commands = Column(Integer, default=0)
    total_messages = Column(Integer, default=0)
    total_work = Column(Integer, default=0)
    total_breaks = Column(Integer, default=0)
    total_hacks = Column(Integer, default=0)
    
    # Achievements & Quests
    achievements = Column(JSON, default=list)  # List of achievement IDs
    completed_quests = Column(JSON, default=list)  # List of quest IDs
    current_quest = Column(String(50), nullable=True)
    quest_progress = Column(JSON, default=dict)
    
    # Daily/Weekly/Monthly
    daily_streak = Column(Integer, default=0)
    last_daily_claim = Column(DateTime, nullable=True)
    weekly_streak = Column(Integer, default=0)
    last_weekly_claim = Column(DateTime, nullable=True)
    monthly_streak = Column(Integer, default=0)
    last_monthly_claim = Column(DateTime, nullable=True)
    
    # Referral System
    referrer_id = Column(BigInteger, nullable=True, index=True)
    referral_code = Column(String(20), unique=True, index=True)
    total_referrals = Column(Integer, default=0)
    referral_earnings = Column(BigInteger, default=0)
    
    # Security & Protection
    guard_active = Column(Boolean, default=False)
    guard_expire = Column(DateTime, nullable=True)
    guard_level = Column(Integer, default=0)
    
    # Anti-Cheat
    suspicious_activity_count = Column(Integer, default=0)
    last_suspicious_activity = Column(DateTime, nullable=True)
    total_violations = Column(Integer, default=0)
    
    # Cooldowns (stored as JSON for flexibility)
    cooldowns = Column(JSON, default=dict)
    
    # Settings & Preferences
    settings = Column(JSON, default=dict)  # User preferences
    notifications = Column(JSON, default=lambda: {
        "daily_reward": True,
        "level_up": True,
        "vip_expire": True,
        "events": True
    })
    
    # Tutorial & Onboarding
    tutorial_completed = Column(Boolean, default=False)
    tutorial_step = Column(Integer, default=0)
    
    # Metadata
    metadata = Column(JSON, default=dict)  # Extra data storage
    notes = Column(Text, nullable=True)  # Admin notes
    
    # Relationships (will be defined later)
    # transactions = relationship("Transaction", back_populates="user")
    # logs = relationship("UserLog", back_populates="user")
    
    # Indexes for performance
    __table_args__ = (
        Index('idx_user_balance', 'balance'),
        Index('idx_user_level', 'level'),
        Index('idx_user_vip', 'is_vip'),
        Index('idx_user_activity', 'last_activity'),
        Index('idx_user_banned', 'is_banned'),
    )
    
    def __repr__(self):
        return f"<User(user_id={self.user_id}, username={self.username}, level={self.level})>"
    
    # ═══════════════════════════════════════════════════════
    # Properties & Methods
    # ═══════════════════════════════════════════════════════
    
    @property
    def is_owner(self) -> bool:
        """Check if user is owner"""
        return self.user_id in settings.OWNER_IDS
    
    @property
    def is_admin(self) -> bool:
        """Check if user is admin"""
        return self.user_id in settings.ADMIN_IDS or self.is_owner
    
    @property
    def total_wealth(self) -> int:
        """Calculate total wealth including all assets"""
        wealth = self.balance + self.bank
        wealth += self.gold * settings.GOLD_PRICE
        wealth += self.diamond * settings.DIAMOND_PRICE
        wealth += self.usd * settings.USD_PRICE
        return wealth
    
    @property
    def display_name(self) -> str:
        """Get display name"""
        if self.username:
            return f"@{self.username}"
        return self.full_name
    
    @property
    def vip_active(self) -> bool:
        """Check if VIP is active"""
        if not self.is_vip:
            return False
        if self.vip_expire and datetime.utcnow() > self.vip_expire:
            return False
        return True
    
    @property
    def job_info(self) -> Dict[str, Any]:
        """Get current job information"""
        return JobConfig.JOBS.get(self.job, JobConfig.JOBS["geda"])
    
    def get_work_earnings(self) -> int:
        """Calculate work earnings"""
        base = self.job_info.get("base_salary", 5000)
        level_bonus = self.level * 1000
        job_level_bonus = self.job_level * 500
        
        earnings = base + level_bonus + job_level_bonus
        
        # VIP multiplier
        if self.vip_active:
            earnings = int(earnings * settings.VIP_WORK_MULTIPLIER)
        
        # Random bonus (10-30%)
        import random
        bonus = random.uniform(1.1, 1.3)
        earnings = int(earnings * bonus)
        
        return earnings
    
    def add_xp(self, amount: int) -> bool:
        """Add XP and check for level up"""
        self.xp += amount
        self.total_xp += amount
        
        leveled_up = False
        while self.xp >= self.xp_next:
            self.xp -= self.xp_next
            self.level += 1
            self.xp_next = self.calculate_xp_for_next_level()
            leveled_up = True
            
            # Level up bonuses
            self.balance += self.level * 10000
            self.energy = 100
        
        return leveled_up
    
    def calculate_xp_for_next_level(self) -> int:
        """Calculate XP needed for next level"""
        return int(1000 * (self.level ** 1.5))
    
    def can_change_job(self) -> bool:
        """Check if user can change job"""
        if not self.last_job_change:
            return True
        
        time_passed = datetime.utcnow() - self.last_job_change
        return time_passed.total_seconds() >= settings.COOLDOWN_JOB_CHANGE
    
    def calculate_tax(self) -> float:
        """Calculate tax rate based on properties"""
        base_rate = settings.BASE_TAX_RATE
        
        # Reduce tax based on properties
        total_reduction = 0
        for prop_type, count in (self.properties or {}).items():
            reduction_per_item = settings.HOME_TAX_REDUCTION
            total_reduction += count * reduction_per_item
        
        final_rate = max(0, base_rate - total_reduction)
        return final_rate
    
    def check_cooldown(self, action: str) -> Tuple[bool, int]:
        """
        Check if action is on cooldown
        
        Returns:
            (is_on_cooldown, remaining_seconds)
        """
        if not self.cooldowns:
            self.cooldowns = {}
        
        last_time = self.cooldowns.get(action, 0)
        if isinstance(last_time, str):
            last_time = datetime.fromisoformat(last_time).timestamp()
        
        cooldown_seconds = getattr(settings, f"COOLDOWN_{action.upper()}", 300)
        
        # VIP cooldown reduction
        if self.vip_active:
            cooldown_seconds = int(cooldown_seconds * (1 - settings.VIP_COOLDOWN_REDUCTION))
        
        current_time = datetime.utcnow().timestamp()
        time_passed = current_time - last_time
        
        if time_passed < cooldown_seconds:
            remaining = int(cooldown_seconds - time_passed)
            return True, remaining
        
        return False, 0
    
    def set_cooldown(self, action: str):
        """Set cooldown for an action"""
        if not self.cooldowns:
            self.cooldowns = {}
        
        self.cooldowns[action] = datetime.utcnow().isoformat()
    
    def update_activity(self):
        """Update last activity timestamp"""
        self.last_activity = datetime.utcnow()
        self.last_seen = datetime.utcnow()
        self.total_commands += 1
    
    def add_balance(self, amount: int, track_earning: bool = True):
        """Add balance safely"""
        self.balance += amount
        if track_earning and amount > 0:
            self.total_earned += amount
        
        # Cap at max balance
        if self.balance > settings.MAX_BALANCE:
            self.balance = settings.MAX_BALANCE
    
    def remove_balance(self, amount: int, track_spending: bool = True) -> bool:
        """Remove balance if sufficient"""
        if self.balance < amount:
            return False
        
        self.balance -= amount
        if track_spending:
            self.total_spent += amount
        
        return True
    
    def generate_api_key(self) -> str:
        """Generate new API key"""
        self.api_key = ''.join(secrets.choice(string.ascii_letters + string.digits) for _ in range(32))
        self.api_key_expire = datetime.utcnow() + timedelta(seconds=settings.API_KEY_EXPIRY)
        return self.api_key
    
    def to_dict(self) -> Dict[str, Any]:
        """Convert to dictionary"""
        return {
            "user_id": self.user_id,
            "username": self.username,
            "full_name": self.full_name,
            "balance": self.balance,
            "bank": self.bank,
            "level": self.level,
            "xp": self.xp,
            "job": self.job,
            "is_vip": self.vip_active,
            "total_wealth": self.total_wealth,
            "wins": self.wins,
            "losses": self.losses,
            "win_rate": self.win_rate
        }
