"""
Transaction model for tracking all financial activities
"""

from datetime import datetime
from typing import Optional
from sqlalchemy import Column, BigInteger, String, Integer, Float, DateTime, JSON, Text, Index, Enum as SQLEnum
from sqlalchemy.orm import relationship
from models.base import Base, TimestampMixin
import enum


class TransactionType(str, enum.Enum):
    """Transaction types"""
    WORK = "work"
    COIN = "coin"
    GAME_WIN = "game_win"
    GAME_LOSS = "game_loss"
    TRANSFER_SEND = "transfer_send"
    TRANSFER_RECEIVE = "transfer_receive"
    PURCHASE = "purchase"
    SALE = "sale"
    BREAK = "break"
    HACK = "hack"
    TAX = "tax"
    DAILY_REWARD = "daily_reward"
    WEEKLY_REWARD = "weekly_reward"
    MONTHLY_REWARD = "monthly_reward"
    REFERRAL = "referral"
    ADMIN_ADD = "admin_add"
    ADMIN_REMOVE = "admin_remove"
    BANK_DEPOSIT = "bank_deposit"
    BANK_WITHDRAW = "bank_withdraw"
    FACTORY_COLLECT = "factory_collect"
    VIP_PURCHASE = "vip_purchase"
    PROPERTY_PURCHASE = "property_purchase"
    WEAPON_PURCHASE = "weapon_purchase"
    CHARITY = "charity"
    OTHER = "other"


class TransactionStatus(str, enum.Enum):
    """Transaction status"""
    PENDING = "pending"
    COMPLETED = "completed"
    FAILED = "failed"
    CANCELLED = "cancelled"
    REVERSED = "reversed"


class Transaction(Base, TimestampMixin):
    """Transaction model - تراکنش‌های مالی"""
    
    __tablename__ = "transactions"
    
    # Primary Key
    id = Column(BigInteger, primary_key=True, autoincrement=True)
    transaction_id = Column(String(50), unique=True, index=True, nullable=False)
    
    # User Info
    user_id = Column(BigInteger, nullable=False, index=True)
    username = Column(String(255), nullable=True)
    
    # Transaction Details
    type = Column(SQLEnum(TransactionType), nullable=False, index=True)
    status = Column(SQLEnum(TransactionStatus), default=TransactionStatus.COMPLETED, index=True)
    
    # Amounts
    amount = Column(BigInteger, nullable=False)
    balance_before = Column(BigInteger, nullable=False)
    balance_after = Column(BigInteger, nullable=False)
    
    # Related User (for transfers, breaks, hacks)
    related_user_id = Column(BigInteger, nullable=True, index=True)
    related_username = Column(String(255), nullable=True)
    
    # Additional Info
    description = Column(Text, nullable=True)
    metadata = Column(JSON, default=dict)
    
    # Game Info (if applicable)
    game_type = Column(String(50), nullable=True)
    bet_amount = Column(BigInteger, nullable=True)
    win_amount = Column(BigInteger, nullable=True)
    
    # Admin Info (if admin action)
    admin_id = Column(BigInteger, nullable=True)
    admin_username = Column(String(255), nullable=True)
    admin_reason = Column(Text, nullable=True)
    
    # Timestamp
    executed_at = Column(DateTime, default=datetime.utcnow, index=True)
    
    # IP & Device (optional security)
    ip_address = Column(String(50), nullable=True)
    user_agent = Column(Text, nullable=True)
    
    # Indexes
    __table_args__ = (
        Index('idx_transaction_user_type', 'user_id', 'type'),
        Index('idx_transaction_date', 'executed_at'),
        Index('idx_transaction_amount', 'amount'),
    )
    
    def __repr__(self):
        return f"<Transaction(id={self.id}, type={self.type}, amount={self.amount})>"


class GameHistory(Base, TimestampMixin):
    """Game history model - تاریخچه بازی‌ها"""
    
    __tablename__ = "game_history"
    
    id = Column(BigInteger, primary_key=True, autoincrement=True)
    
    # User Info
    user_id = Column(BigInteger, nullable=False, index=True)
    username = Column(String(255), nullable=True)
    
    # Game Details
    game_type = Column(String(50), nullable=False, index=True)
    bet_amount = Column(BigInteger, nullable=False)
    result = Column(String(20), nullable=False)  # win, loss, tie
    win_amount = Column(BigInteger, default=0)
    
    # Game Data
    game_data = Column(JSON, default=dict)  # dice result, slot symbols, etc.
    
    # Opponent (for challenges)
    opponent_id = Column(BigInteger, nullable=True)
    opponent_username = Column(String(255), nullable=True)
    
    # Statistics
    multiplier = Column(Float, default=1.0)
    is_jackpot = Column(Boolean, default=False)
    is_vip_game = Column(Boolean, default=False)
    
    played_at = Column(DateTime, default=datetime.utcnow, index=True)
    
    __table_args__ = (
        Index('idx_game_user', 'user_id', 'played_at'),
        Index('idx_game_type', 'game_type'),
    )


class DailyReward(Base, TimestampMixin):
    """Daily reward tracking"""
    
    __tablename__ = "daily_rewards"
    
    id = Column(BigInteger, primary_key=True, autoincrement=True)
    user_id = Column(BigInteger, nullable=False, index=True)
    
    reward_type = Column(String(20), nullable=False)  # daily, weekly, monthly
    reward_amount = Column(BigInteger, nullable=False)
    streak = Column(Integer, default=1)
    
    claimed_at = Column(DateTime, default=datetime.utcnow, index=True)
    
    __table_args__ = (
        Index('idx_reward_user_type', 'user_id', 'reward_type'),
    )
