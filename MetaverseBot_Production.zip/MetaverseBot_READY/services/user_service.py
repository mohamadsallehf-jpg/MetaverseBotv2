"""
User service for all user-related operations
"""

from typing import Optional, List, Dict, Any
from datetime import datetime, timedelta
from sqlalchemy import select, func, or_, and_
from sqlalchemy.ext.asyncio import AsyncSession
from models.user import User
from models.transaction import Transaction, TransactionType, TransactionStatus
from models.log import UserLog, LogLevel, LogCategory
from config import settings
from services.cache import cache
from loguru import logger
import secrets
import string


class UserService:
    """User management service"""
    
    def __init__(self, session: AsyncSession):
        self.session = session
    
    # ═══════════════════════════════════════════════════════
    # User Creation & Registration
    # ═══════════════════════════════════════════════════════
    
    async def create_user(
        self,
        user_id: int,
        username: Optional[str],
        first_name: str,
        last_name: Optional[str] = None,
        referrer_id: Optional[int] = None
    ) -> User:
        """Create new user"""
        
        # Check if user exists
        existing = await self.get_user(user_id)
        if existing:
            return existing
        
        # Generate unique codes
        secret_code = self._generate_secret_code()
        referral_code = self._generate_referral_code()
        
        # Create user
        user = User(
            user_id=user_id,
            username=username,
            first_name=first_name,
            last_name=last_name,
            full_name=f"{first_name} {last_name or ''}".strip(),
            secret_code=secret_code,
            referral_code=referral_code,
            referrer_id=referrer_id,
            balance=settings.INITIAL_BALANCE,
            bank=settings.INITIAL_BANK,
            level=settings.INITIAL_LEVEL,
            xp=settings.INITIAL_XP
        )
        
        self.session.add(user)
        await self.session.commit()
        await self.session.refresh(user)
        
        # Process referral bonus
        if referrer_id:
            await self.process_referral(referrer_id, user_id)
        
        # Cache user
        await cache.cache_user(user_id, user.to_dict())
        
        logger.info(f"✅ New user created: {user_id} (@{username})")
        
        return user
    
    def _generate_secret_code(self) -> str:
        """Generate unique secret code"""
        return ''.join(secrets.choice(string.ascii_uppercase + string.digits) for _ in range(9))
    
    def _generate_referral_code(self) -> str:
        """Generate unique referral code"""
        return ''.join(secrets.choice(string.ascii_lowercase + string.digits) for _ in range(8))
    
    # ═══════════════════════════════════════════════════════
    # User Retrieval
    # ═══════════════════════════════════════════════════════
    
    async def get_user(self, user_id: int, use_cache: bool = True) -> Optional[User]:
        """Get user by ID"""
        
        # Try cache first
        if use_cache:
            cached = await cache.get_cached_user(user_id)
            if cached:
                # Return from DB to get full object
                pass
        
        result = await self.session.execute(
            select(User).where(User.user_id == user_id)
        )
        user = result.scalar_one_or_none()
        
        if user and use_cache:
            await cache.cache_user(user_id, user.to_dict())
        
        return user
    
    async def get_user_by_username(self, username: str) -> Optional[User]:
        """Get user by username"""
        result = await self.session.execute(
            select(User).where(User.username == username.lower())
        )
        return result.scalar_one_or_none()
    
    async def get_users_batch(self, user_ids: List[int]) -> List[User]:
        """Get multiple users at once"""
        result = await self.session.execute(
            select(User).where(User.user_id.in_(user_ids))
        )
        return result.scalars().all()
    
    # ═══════════════════════════════════════════════════════
    # Balance Operations
    # ═══════════════════════════════════════════════════════
    
    async def add_balance(
        self,
        user_id: int,
        amount: int,
        transaction_type: TransactionType,
        description: Optional[str] = None,
        metadata: Optional[Dict] = None
    ) -> bool:
        """Add balance to user"""
        
        user = await self.get_user(user_id)
        if not user:
            return False
        
        balance_before = user.balance
        user.add_balance(amount)
        
        # Create transaction record
        await self._create_transaction(
            user=user,
            amount=amount,
            balance_before=balance_before,
            balance_after=user.balance,
            transaction_type=transaction_type,
            description=description,
            metadata=metadata
        )
        
        await self.session.commit()
        
        # Update cache
        await cache.cache_user(user_id, user.to_dict())
        
        return True
    
    async def remove_balance(
        self,
        user_id: int,
        amount: int,
        transaction_type: TransactionType,
        description: Optional[str] = None
    ) -> bool:
        """Remove balance from user"""
        
        user = await self.get_user(user_id)
        if not user:
            return False
        
        if user.balance < amount:
            return False
        
        balance_before = user.balance
        user.remove_balance(amount)
        
        await self._create_transaction(
            user=user,
            amount=-amount,
            balance_before=balance_before,
            balance_after=user.balance,
            transaction_type=transaction_type,
            description=description
        )
        
        await self.session.commit()
        await cache.cache_user(user_id, user.to_dict())
        
        return True
    
    async def transfer_balance(
        self,
        from_user_id: int,
        to_user_id: int,
        amount: int
    ) -> tuple[bool, Optional[str]]:
        """Transfer balance between users"""
        
        # Get both users
        from_user = await self.get_user(from_user_id)
        to_user = await self.get_user(to_user_id)
        
        if not from_user or not to_user:
            return False, "کاربر یافت نشد"
        
        # Calculate fee
        fee = int(amount * settings.TRANSFER_FEE)
        total = amount + fee
        
        if from_user.balance < total:
            return False, f"موجودی کافی نیست (نیاز: {total:,} تومان)"
        
        # Execute transfer
        from_user.remove_balance(total)
        to_user.add_balance(amount)
        
        # Log transactions
        await self._create_transaction(
            user=from_user,
            amount=-total,
            balance_before=from_user.balance + total,
            balance_after=from_user.balance,
            transaction_type=TransactionType.TRANSFER_SEND,
            related_user_id=to_user_id,
            description=f"Transfer to {to_user.display_name}"
        )
        
        await self._create_transaction(
            user=to_user,
            amount=amount,
            balance_before=to_user.balance - amount,
            balance_after=to_user.balance,
            transaction_type=TransactionType.TRANSFER_RECEIVE,
            related_user_id=from_user_id,
            description=f"Transfer from {from_user.display_name}"
        )
        
        await self.session.commit()
        
        # Update caches
        await cache.cache_user(from_user_id, from_user.to_dict())
        await cache.cache_user(to_user_id, to_user.to_dict())
        
        return True, None
    
    async def _create_transaction(
        self,
        user: User,
        amount: int,
        balance_before: int,
        balance_after: int,
        transaction_type: TransactionType,
        description: Optional[str] = None,
        metadata: Optional[Dict] = None,
        related_user_id: Optional[int] = None
    ):
        """Create transaction record"""
        
        transaction = Transaction(
            transaction_id=self._generate_transaction_id(),
            user_id=user.user_id,
            username=user.username,
            type=transaction_type,
            status=TransactionStatus.COMPLETED,
            amount=amount,
            balance_before=balance_before,
            balance_after=balance_after,
            related_user_id=related_user_id,
            description=description,
            metadata=metadata or {}
        )
        
        self.session.add(transaction)
    
    def _generate_transaction_id(self) -> str:
        """Generate unique transaction ID"""
        timestamp = datetime.utcnow().strftime("%Y%m%d%H%M%S")
        random_part = ''.join(secrets.choice(string.digits) for _ in range(6))
        return f"TXN{timestamp}{random_part}"
    
    # More methods for XP, VIP, jobs, etc. would go here...
    
    async def add_xp(self, user_id: int, amount: int) -> tuple[bool, bool]:
        """Add XP to user, returns (success, leveled_up)"""
        user = await self.get_user(user_id)
        if not user:
            return False, False
        
        leveled_up = user.add_xp(amount)
        await self.session.commit()
        
        if leveled_up:
            logger.success(f"🎉 User {user_id} leveled up to {user.level}!")
        
        await cache.cache_user(user_id, user.to_dict())
        return True, leveled_up
    
    async def process_referral(self, referrer_id: int, new_user_id: int):
        """Process referral bonus"""
        referrer = await self.get_user(referrer_id)
        if not referrer:
            return
        
        # Give bonus to referrer
        referrer.total_referrals += 1
        referrer.referral_earnings += settings.REFERRAL_BONUS
        await self.add_balance(
            referrer_id,
            settings.REFERRAL_BONUS,
            TransactionType.REFERRAL,
            f"Referral bonus for user {new_user_id}"
        )
        
        logger.info(f"💰 Referral bonus {settings.REFERRAL_BONUS:,} given to {referrer_id}")
    
    # ═══════════════════════════════════════════════════════
    # Statistics & Leaderboard
    # ═══════════════════════════════════════════════════════
    
    async def get_leaderboard(self, limit: int = 10) -> List[User]:
        """Get top users by total wealth"""
        from sqlalchemy import desc, func
        
        # Calculate total wealth for each user and order by it
        result = await self.session.execute(
            select(User)
            .where(User.is_banned == False)
            .order_by(desc(User.balance + User.bank))
            .limit(limit)
        )
        
        return result.scalars().all()
    
    async def get_user_rank(self, user_id: int) -> int:
        """Get user's rank by wealth"""
        from sqlalchemy import func
        
        user = await self.get_user(user_id)
        if not user:
            return 0
        
        user_wealth = user.total_wealth
        
        # Count users with more wealth
        result = await self.session.execute(
            select(func.count(User.user_id))
            .where(
                User.is_banned == False,
                (User.balance + User.bank) > user_wealth
            )
        )
        
        rank = result.scalar() + 1
        return rank
    
    async def get_total_users(self) -> int:
        """Get total number of users"""
        from sqlalchemy import func
        
        result = await self.session.execute(
            select(func.count(User.user_id))
        )
        return result.scalar() or 0
    
    async def get_active_users_count(self) -> int:
        """Get count of active users (last 7 days)"""
        from sqlalchemy import func
        from datetime import datetime, timedelta
        
        week_ago = datetime.utcnow() - timedelta(days=7)
        
        result = await self.session.execute(
            select(func.count(User.user_id))
            .where(
                User.is_banned == False,
                User.last_activity >= week_ago
            )
        )
        return result.scalar() or 0
    
    async def get_vip_users_count(self) -> int:
        """Get count of VIP users"""
        from sqlalchemy import func
        
        result = await self.session.execute(
            select(func.count(User.user_id))
            .where(User.is_vip == True)
        )
        return result.scalar() or 0
    
    async def get_banned_users_count(self) -> int:
        """Get count of banned users"""
        from sqlalchemy import func
        
        result = await self.session.execute(
            select(func.count(User.user_id))
            .where(User.is_banned == True)
        )
        return result.scalar() or 0
    
    async def get_total_balance(self) -> int:
        """Get total balance of all users"""
        from sqlalchemy import func
        
        result = await self.session.execute(
            select(func.sum(User.balance))
        )
        return result.scalar() or 0
    
    async def get_total_bank(self) -> int:
        """Get total bank balance of all users"""
        from sqlalchemy import func
        
        result = await self.session.execute(
            select(func.sum(User.bank))
        )
        return result.scalar() or 0
    
    async def get_total_games(self) -> int:
        """Get total number of games played"""
        from sqlalchemy import func
        
        result = await self.session.execute(
            select(func.sum(User.total_games))
        )
        return result.scalar() or 0
    
    async def get_total_wins(self) -> int:
        """Get total wins"""
        from sqlalchemy import func
        
        result = await self.session.execute(
            select(func.sum(User.wins))
        )
        return result.scalar() or 0
    
    async def get_total_losses(self) -> int:
        """Get total losses"""
        from sqlalchemy import func
        
        result = await self.session.execute(
            select(func.sum(User.losses))
        )
        return result.scalar() or 0
    
    async def get_total_transactions(self) -> int:
        """Get total transaction count"""
        from sqlalchemy import func
        
        result = await self.session.execute(
            select(func.count(Transaction.id))
        )
        return result.scalar() or 0
