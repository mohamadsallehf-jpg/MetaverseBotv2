"""
Admin command handlers
"""

from telegram import Update
from telegram.ext import ContextTypes
from telegram.constants import ParseMode
from middlewares.security import require_admin, require_owner, security
from models.base import db_manager
from services.user_service import UserService
from datetime import datetime, timedelta


@require_admin
async def admin_panel(update: Update, context: ContextTypes.DEFAULT_TYPE):
    """Admin panel"""
    admin_text = """
👮 <b>پنل ادمین</b>

<b>مدیریت کاربران:</b>
/ban @username [reason] - بن کاربر
/unban @username - رفع بن
/mute @username [minutes] - سکوت
/unmute @username - رفع سکوت
/warn @username [reason] - اخطار

<b>مدیریت موجودی:</b>
/addcoin @username مقدار - افزودن سکه
/removecoin @username مقدار - کسر سکه
/setbalance @username مقدار - تنظیم موجودی

<b>VIP:</b>
/givevip @username [days] - اعطای VIP
/removevip @username - حذف VIP

<b>آمار:</b>
/stats - آمار کلی
/users - لیست کاربران
/online - کاربران آنلاین

<b>اطلاعیه:</b>
/broadcast [message] - ارسال به همه
"""
    
    await update.message.reply_text(admin_text, parse_mode=ParseMode.HTML)


@require_owner
async def owner_panel(update: Update, context: ContextTypes.DEFAULT_TYPE):
    """Owner panel"""
    owner_text = """
👑 <b>پنل مالک</b>

<b>مدیریت ادمین:</b>
/addadmin @username - افزودن ادمین
/removeadmin @username - حذف ادمین
/admins - لیست ادمین‌ها

<b>سیستم:</b>
/backup - دریافت بکاپ
/restore - بازیابی از بکاپ
/logs - مشاهده لاگ‌ها
/systeminfo - اطلاعات سیستم

<b>تنظیمات:</b>
/setprice usd [price] - تنظیم قیمت دلار
/setcooldown [action] [seconds] - تنظیم کولداون
/toggle [feature] - فعال/غیرفعال کردن

<b>داده‌ها:</b>
/resetuser @username - ریست کاربر
/deleteuser @username - حذف کاربر
/fullreset - ریست کامل (خطرناک!)
"""
    
    await update.message.reply_text(owner_text, parse_mode=ParseMode.HTML)


@require_admin
async def ban_user(update: Update, context: ContextTypes.DEFAULT_TYPE):
    """Ban a user"""
    if not context.args:
        await update.message.reply_text(
            "⚠️ استفاده: /ban @username [reason] [days]\n"
            "مثال: /ban @user spam 7"
        )
        return
    
    username = context.args[0].replace("@", "")
    reason = " ".join(context.args[1:-1]) if len(context.args) > 2 else "No reason"
    days = int(context.args[-1]) if len(context.args) > 2 and context.args[-1].isdigit() else 0
    
    async with db_manager.session() as session:
        user_service = UserService(session)
        
        # Find user
        user = await user_service.get_user_by_username(username)
        if not user:
            await update.message.reply_text(f"❌ کاربر @{username} یافت نشد!")
            return
        
        # Ban user
        user.is_banned = True
        user.ban_reason = reason
        
        if days > 0:
            user.ban_expire = datetime.utcnow() + timedelta(days=days)
            ban_text = f"{days} روز"
        else:
            user.ban_expire = None
            ban_text = "نامحدود"
        
        await session.commit()
        
        await update.message.reply_text(
            f"✅ کاربر @{username} بن شد!\n\n"
            f"📝 دلیل: {reason}\n"
            f"⏰ مدت: {ban_text}"
        )


@require_admin
async def mute_user(update: Update, context: ContextTypes.DEFAULT_TYPE):
    """Mute a user"""
    if not context.args:
        await update.message.reply_text(
            "⚠️ استفاده: /mute @username [minutes]"
        )
        return
    
    username = context.args[0].replace("@", "")
    minutes = int(context.args[1]) if len(context.args) > 1 else 60
    
    async with db_manager.session() as session:
        user_service = UserService(session)
        
        user = await user_service.get_user_by_username(username)
        if not user:
            await update.message.reply_text(f"❌ کاربر @{username} یافت نشد!")
            return
        
        user.is_muted = True
        user.mute_expire = datetime.utcnow() + timedelta(minutes=minutes)
        
        await session.commit()
        
        await update.message.reply_text(
            f"🔇 کاربر @{username} برای {minutes} دقیقه سکوت شد!"
        )


@require_admin
async def stats_command(update: Update, context: ContextTypes.DEFAULT_TYPE):
    """Show bot statistics"""
    async with db_manager.session() as session:
        user_service = UserService(session)
        
        # Get stats
        total_users = await user_service.get_total_users()
        active_users = await user_service.get_active_users_count()
        vip_users = await user_service.get_vip_users_count()
        banned_users = await user_service.get_banned_users_count()
        
        # Get economy stats
        total_balance = await user_service.get_total_balance()
        total_bank = await user_service.get_total_bank()
        total_transactions = await user_service.get_total_transactions()
        
        # Get game stats  
        total_games = await user_service.get_total_games()
        total_wins = await user_service.get_total_wins()
        total_losses = await user_service.get_total_losses()
        
        win_rate = (total_wins / total_games * 100) if total_games > 0 else 0
        
        stats_text = f"""
📊 <b>آمار ربات</b>

━━━━━━━━━━━━━━━
<b>👥 کاربران</b>
کل کاربران: {total_users:,}
کاربران فعال: {active_users:,}
کاربران VIP: {vip_users:,}
کاربران بن شده: {banned_users:,}

━━━━━━━━━━━━━━━
<b>💰 اقتصاد</b>
کل سکه در گردش: {total_balance:,} تومان
کل پول در بانک: {total_bank:,} تومان
میانگین موجودی: {(total_balance // total_users) if total_users > 0 else 0:,} تومان
کل تراکنش‌ها: {total_transactions:,}

━━━━━━━━━━━━━━━
<b>🎮 بازی</b>
کل بازی‌ها: {total_games:,}
برد: {total_wins:,}
باخت: {total_losses:,}
نرخ برد: {win_rate:.1f}%

━━━━━━━━━━━━━━━
<b>📅 سیستم</b>
وضعیت: 🟢 آنلاین
آپتایم: -- ساعت
"""
        
        await update.message.reply_text(stats_text, parse_mode=ParseMode.HTML)


@require_admin
async def give_vip_command(update: Update, context: ContextTypes.DEFAULT_TYPE):
    """Give VIP to user"""
    if len(context.args) < 2:
        await update.message.reply_text(
            "⚠️ استفاده: /givevip @username [days]\n"
            "مثال: /givevip @user 30"
        )
        return
    
    username = context.args[0].replace("@", "")
    days = int(context.args[1])
    
    async with db_manager.session() as session:
        user_service = UserService(session)
        
        user = await user_service.get_user_by_username(username)
        if not user:
            await update.message.reply_text(f"❌ کاربر @{username} یافت نشد!")
            return
        
        # Give VIP
        user.is_vip = True
        user.vip_expire = datetime.utcnow() + timedelta(days=days)
        user.account_type = "VIP"
        
        await session.commit()
        
        await update.message.reply_text(
            f"✅ VIP به @{username} اعطا شد!\n\n"
            f"⏰ مدت: {days} روز\n"
            f"📅 تا تاریخ: {user.vip_expire.strftime('%Y-%m-%d')}"
        )


@require_admin
async def remove_vip_command(update: Update, context: ContextTypes.DEFAULT_TYPE):
    """Remove VIP from user"""
    if not context.args:
        await update.message.reply_text(
            "⚠️ استفاده: /removevip @username"
        )
        return
    
    username = context.args[0].replace("@", "")
    
    async with db_manager.session() as session:
        user_service = UserService(session)
        
        user = await user_service.get_user_by_username(username)
        if not user:
            await update.message.reply_text(f"❌ کاربر @{username} یافت نشد!")
            return
        
        user.is_vip = False
        user.vip_expire = None
        user.account_type = "کاربر معمولی"
        
        await session.commit()
        
        await update.message.reply_text(
            f"✅ VIP از @{username} حذف شد!"
        )


@require_admin
async def add_coin_command(update: Update, context: ContextTypes.DEFAULT_TYPE):
    """Add coins to user"""
    if len(context.args) < 2:
        await update.message.reply_text(
            "⚠️ استفاده: /addcoin @username مقدار\n"
            "مثال: /addcoin @user 1000000"
        )
        return
    
    username = context.args[0].replace("@", "")
    
    try:
        amount = int(context.args[1].replace(",", ""))
    except Exception as e:
        await update.message.reply_text("❌ مقدار نامعتبر است!")
        return
    
    async with db_manager.session() as session:
        user_service = UserService(session)
        
        user = await user_service.get_user_by_username(username)
        if not user:
            await update.message.reply_text(f"❌ کاربر @{username} یافت نشد!")
            return
        
        user.balance += amount
        
        await session.commit()
        
        user = await user_service.get_user_by_username(username)
        
        await update.message.reply_text(
            f"✅ {amount:,} تومان به @{username} اضافه شد!\n\n"
            f"💰 موجودی جدید: {user.balance:,} تومان"
        )


@require_admin
async def remove_coin_command(update: Update, context: ContextTypes.DEFAULT_TYPE):
    """Remove coins from user"""
    if len(context.args) < 2:
        await update.message.reply_text(
            "⚠️ استفاده: /removecoin @username مقدار\n"
            "مثال: /removecoin @user 1000000"
        )
        return
    
    username = context.args[0].replace("@", "")
    
    try:
        amount = int(context.args[1].replace(",", ""))
    except Exception as e:
        await update.message.reply_text("❌ مقدار نامعتبر است!")
        return
    
    async with db_manager.session() as session:
        user_service = UserService(session)
        
        user = await user_service.get_user_by_username(username)
        if not user:
            await update.message.reply_text(f"❌ کاربر @{username} یافت نشد!")
            return
        
        user.balance -= amount
        if user.balance < 0:
            user.balance = 0
        
        await session.commit()
        
        user = await user_service.get_user_by_username(username)
        
        await update.message.reply_text(
            f"✅ {amount:,} تومان از @{username} کسر شد!\n\n"
            f"💰 موجودی جدید: {user.balance:,} تومان"
        )


@require_owner
async def backup_command(update: Update, context: ContextTypes.DEFAULT_TYPE):
    """Create backup"""
    await update.message.reply_text(
        "💾 در حال ایجاد نسخه پشتیبان..."
    )
    
    # Create backup
    # await database.backup()
    
    await update.message.reply_text(
        "✅ نسخه پشتیبان با موفقیت ایجاد شد!\n"
        "📁 فایل آماده دانلود است."
    )
