"""
Economy command handlers
"""

from telegram import Update
from telegram.ext import ContextTypes
from telegram.constants import ParseMode
from middlewares.security import require_group, require_channel, rate_limit, security
from config import settings, WeaponConfig
from models.base import db_manager
from services.user_service import UserService
from models.transaction import TransactionType
from loguru import logger
import random


@require_group
@require_channel
@rate_limit("coin", max_requests=1, window=settings.COOLDOWN_COIN)
async def coin_command(update: Update, context: ContextTypes.DEFAULT_TYPE):
    """Free coin command"""
    user_id = update.effective_user.id
    
    async with db_manager.session() as session:
        user_service = UserService(session)
        
        # Get or create user
        user = await user_service.get_user(user_id)
        if not user:
            user = await user_service.create_user(
                user_id=user_id,
                username=update.effective_user.username,
                first_name=update.effective_user.first_name,
                last_name=update.effective_user.last_name
            )
        
        # Random amount
        amount = random.randint(5000, 25000)
        
        # Add balance
        await user_service.add_balance(user_id, amount, "coin_reward")
        
        # Add XP
        xp_gain = amount // 1000
        leveled_up = await user_service.add_xp(user_id, xp_gain)
        
        await session.commit()
        
        # Refresh user data
        user = await user_service.get_user(user_id, use_cache=False)
        
        response = (
            f"💰 شما {amount:,} تومان سکه رایگان دریافت کردید!\n"
            f"💫 +{xp_gain} XP\n\n"
            f"💵 موجودی جدید: {user.balance:,} تومان\n"
            f"📊 سطح: {user.level}\n"
            f"⏰ بعدی: {settings.COOLDOWN_COIN // 60} دقیقه دیگر"
        )
        
        if leveled_up:
            response += f"\n\n🎉 تبریک! به سطح {user.level} رسیدید!"
        
        await update.message.reply_text(response)


@require_group
@require_channel
@rate_limit("work", max_requests=1, window=settings.COOLDOWN_WORK)
async def work_command(update: Update, context: ContextTypes.DEFAULT_TYPE):
    """Work command"""
    user_id = update.effective_user.id
    
    async with db_manager.session() as session:
        user_service = UserService(session)
        
        # Get or create user
        user = await user_service.get_user(user_id)
        if not user:
            user = await user_service.create_user(
                user_id=user_id,
                username=update.effective_user.username,
                first_name=update.effective_user.first_name,
                last_name=update.effective_user.last_name
            )
        
        # Calculate real earnings based on job and level
        earnings = user.get_work_earnings()
        xp_gained = earnings // 1000
        
        # Add balance and XP
        await user_service.add_balance(user_id, earnings, "work")
        leveled_up = await user_service.add_xp(user_id, xp_gained)
        
        # Update work stats
        user.total_work += 1
        
        await session.commit()
        
        # Refresh user
        user = await user_service.get_user(user_id, use_cache=False)
        
        # Job-specific messages
        job_info = user.job_info
        messages = [
            f"👷 شما به عنوان {job_info['name']} کار کردید و {earnings:,} تومان به دست آوردید!",
            f"💪 شما امروز به عنوان {job_info['name']} سخت کار کردید! {earnings:,} تومان",
            f"🎯 کار شما به عنوان {job_info['name']} عالی بود! {earnings:,} تومان",
        ]
        
        response = (
            f"{random.choice(messages)}\n\n"
            f"💫 +{xp_gained} XP\n"
            f"💰 موجودی: {user.balance:,} تومان\n"
            f"📊 سطح: {user.level}\n"
            f"⏰ بعدی: {settings.COOLDOWN_WORK // 60} دقیقه دیگر"
        )
        
        if leveled_up:
            response += f"\n\n🎉 تبریک! به سطح {user.level} رسیدید!"
        
        await update.message.reply_text(response)


@require_group
@require_channel
async def pay_command(update: Update, context: ContextTypes.DEFAULT_TYPE):
    """Pay/transfer to another user"""
    if len(context.args) < 2:
        await update.message.reply_text(
            "⚠️ استفاده صحیح: /pay @username مقدار\n"
            "مثال: /pay @john 10000"
        )
        return
    
    user_id = update.effective_user.id
    target_username = context.args[0].replace("@", "")
    
    # Validate amount
    is_valid, amount, error = security.validate_amount(
        context.args[1],
        min_amount=1000
    )
    
    if not is_valid:
        await update.message.reply_text(f"❌ {error}")
        return
    
    async with db_manager.session() as session:
        user_service = UserService(session)
        
        # Get sender
        sender = await user_service.get_user(user_id)
        if not sender:
            await update.message.reply_text("❌ شما ثبت‌نام نکرده‌اید! /start بزنید")
            return
        
        # Find receiver by username
        receiver = await user_service.get_user_by_username(target_username)
        if not receiver:
            await update.message.reply_text(f"❌ کاربر @{target_username} یافت نشد!")
            return
        
        # Check if trying to send to self
        if sender.user_id == receiver.user_id:
            await update.message.reply_text("❌ نمی‌توانید به خودتان پول بفرستید!")
            return
        
        # Calculate fee
        fee = int(amount * settings.TRANSFER_FEE)
        total = amount + fee
        
        # Check balance
        if sender.balance < total:
            await update.message.reply_text(
                f"❌ موجودی کافی نیست!\n\n"
                f"💰 موجودی شما: {sender.balance:,} تومان\n"
                f"💸 نیاز: {total:,} تومان (مبلغ + کارمزد)"
            )
            return
        
        # Transfer money
        await user_service.transfer_money(
            from_user_id=sender.user_id,
            to_user_id=receiver.user_id,
            amount=amount,
            fee=fee
        )
        
        await session.commit()
        
        # Refresh data
        sender = await user_service.get_user(user_id, use_cache=False)
        
        await update.message.reply_text(
            f"✅ {amount:,} تومان به @{target_username} منتقل شد!\n\n"
            f"💸 کارمزد: {fee:,} تومان ({int(settings.TRANSFER_FEE*100)}%)\n"
            f"💰 جمع پرداختی: {total:,} تومان\n\n"
            f"💵 موجودی باقی‌مانده: {sender.balance:,} تومان"
        )


@require_group
@require_channel
async def bank_deposit_command(update: Update, context: ContextTypes.DEFAULT_TYPE):
    """Deposit to bank"""
    if not context.args:
        await update.message.reply_text(
            "⚠️ استفاده صحیح: /transfer [مقدار یا *]\n"
            "مثال: /transfer 100000\n"
            "برای واریز همه: /transfer *"
        )
        return
    
    user_id = update.effective_user.id
    amount_str = context.args[0]
    
    async with db_manager.session() as session:
        user_service = UserService(session)
        
        user = await user_service.get_user(user_id)
        if not user:
            await update.message.reply_text("❌ شما ثبت‌نام نکرده‌اید! /start بزنید")
            return
        
        # Determine amount
        if amount_str == "*":
            amount = user.balance
        else:
            is_valid, amount, error = security.validate_amount(amount_str, min_amount=1000)
            if not is_valid:
                await update.message.reply_text(f"❌ {error}")
                return
        
        # Check balance
        if user.balance < amount:
            await update.message.reply_text(
                f"❌ موجودی کافی نیست!\n"
                f"💰 موجودی: {user.balance:,} تومان"
            )
            return
        
        if amount == 0:
            await update.message.reply_text("❌ موجودی شما صفر است!")
            return
        
        # Transfer to bank
        user.balance -= amount
        user.bank += amount
        
        await session.commit()
        
        # Refresh
        user = await user_service.get_user(user_id, use_cache=False)
        
        await update.message.reply_text(
            f"🏦 {amount:,} تومان به بانک واریز شد!\n\n"
            f"💰 موجودی کیف: {user.balance:,} تومان\n"
            f"🏦 موجودی بانک: {user.bank:,} تومان"
        )


@require_group
@require_channel
async def bank_withdraw_command(update: Update, context: ContextTypes.DEFAULT_TYPE):
    """Withdraw from bank"""
    if not context.args:
        await update.message.reply_text(
            "⚠️ استفاده صحیح: /withdraw [مقدار یا *]\n"
            "مثال: /withdraw 100000\n"
            "برای برداشت همه: /withdraw *"
        )
        return
    
    user_id = update.effective_user.id
    amount_str = context.args[0]
    
    async with db_manager.session() as session:
        user_service = UserService(session)
        
        user = await user_service.get_user(user_id)
        if not user:
            await update.message.reply_text("❌ شما ثبت‌نام نکرده‌اید! /start بزنید")
            return
        
        # Determine amount
        if amount_str == "*":
            amount = user.bank
        else:
            is_valid, amount, error = security.validate_amount(amount_str, min_amount=1000)
            if not is_valid:
                await update.message.reply_text(f"❌ {error}")
                return
        
        # Check bank balance
        if user.bank < amount:
            await update.message.reply_text(
                f"❌ موجودی بانک کافی نیست!\n"
                f"🏦 موجودی بانک: {user.bank:,} تومان"
            )
            return
        
        if amount == 0:
            await update.message.reply_text("❌ موجودی بانک شما صفر است!")
            return
        
        # Calculate fee
        fee = int(amount * settings.BANK_WITHDRAW_FEE)
        total_received = amount - fee
        
        # Withdraw
        user.bank -= amount
        user.balance += total_received
        
        await session.commit()
        
        # Refresh
        user = await user_service.get_user(user_id, use_cache=False)
        
        await update.message.reply_text(
            f"🏦 {total_received:,} تومان از بانک برداشت شد!\n\n"
            f"💸 کارمزد: {fee:,} تومان ({int(settings.BANK_WITHDRAW_FEE*100)}%)\n"
            f"💰 دریافتی: {total_received:,} تومان\n\n"
            f"💵 موجودی کیف: {user.balance:,} تومان\n"
            f"🏦 موجودی بانک: {user.bank:,} تومان"
        )

@require_group
@require_channel
@rate_limit("daily", max_requests=1, window=settings.COOLDOWN_DAILY)
async def daily_reward_command(update: Update, context: ContextTypes.DEFAULT_TYPE):
    """Daily reward command"""
    user_id = update.effective_user.id
    
    async with db_manager.session() as session:
        user_service = UserService(session)
        
        user = await user_service.get_user(user_id)
        if not user:
            await update.message.reply_text("❌ شما ثبت‌نام نکرده‌اید! /start بزنید")
            return
        
        # Check cooldown
        from datetime import datetime, timedelta
        if user.last_daily_claim:
            time_passed = datetime.utcnow() - user.last_daily_claim
            if time_passed.total_seconds() < settings.COOLDOWN_DAILY:
                remaining = settings.COOLDOWN_DAILY - time_passed.total_seconds()
                hours = int(remaining // 3600)
                minutes = int((remaining % 3600) // 60)
                await update.message.reply_text(
                    f"⏰ شما قبلاً امروز جایزه دریافت کرده‌اید!\n"
                    f"زمان باقی‌مانده: {hours} ساعت و {minutes} دقیقه"
                )
                return
        
        # Calculate reward
        base_reward = settings.DAILY_REWARD
        if user.vip_active:
            base_reward += settings.VIP_DAILY_BONUS
        
        # Streak bonus
        if user.last_daily_claim:
            last_claim_date = user.last_daily_claim.date()
            today = datetime.utcnow().date()
            yesterday = today - timedelta(days=1)
            
            if last_claim_date == yesterday:
                # Continue streak
                user.daily_streak += 1
            elif last_claim_date < yesterday:
                # Reset streak
                user.daily_streak = 1
        else:
            user.daily_streak = 1
        
        # Streak bonus (1000 per day)
        streak_bonus = min(user.daily_streak * 1000, 30000)  # Max 30 days
        total_reward = base_reward + streak_bonus
        
        # Add reward
        await user_service.add_balance(user_id, total_reward, "daily_reward")
        user.last_daily_claim = datetime.utcnow()
        
        await session.commit()
        
        # Refresh
        user = await user_service.get_user(user_id, use_cache=False)
        
        response = (
            f"🎁 جایزه روزانه دریافت شد!\n\n"
            f"💰 پاداش پایه: {base_reward:,} تومان\n"
        )
        
        if user.vip_active:
            response += f"⭐ بونوس VIP: {settings.VIP_DAILY_BONUS:,} تومان\n"
        
        if streak_bonus > 0:
            response += f"🔥 بونوس {user.daily_streak} روز متوالی: {streak_bonus:,} تومان\n"
        
        response += (
            f"\n💵 جمع دریافتی: {total_reward:,} تومان\n"
            f"💰 موجودی جدید: {user.balance:,} تومان\n\n"
            f"🔥 Streak: {user.daily_streak} روز"
        )
        
        await update.message.reply_text(response)


@require_group
@require_channel
async def market_command(update: Update, context: ContextTypes.DEFAULT_TYPE):
    """Show market"""
    market_text = """
🏪 <b>بازار</b>

━━━━━━━━━━━━━━━
<b>💎 VIP</b>
قیمت: 50,000,000 تومان
/getvip - خرید VIP

━━━━━━━━━━━━━━━
<b>⚔️ سلاح‌ها</b>
/guns - مشاهده لیست

━━━━━━━━━━━━━━━
<b>💵 ارز</b>
قیمت دلار: 83,750 تومان
/buyusd [مقدار] - خرید
/sellusd [مقدار] - فروش

━━━━━━━━━━━━━━━
<b>🏠 املاک</b>
خانه کوچک: 20,000,000 تومان
خانه متوسط: 50,000,000 تومان
خانه بزرگ: 150,000,000 تومان

━━━━━━━━━━━━━━━
<b>🏭 کارخانه‌ها</b>
کارخانه سنگ: 50,000,000 تومان
کارخانه چوب: 40,000,000 تومان
معدن طلا: 200,000,000 تومان
"""
    
    await update.message.reply_text(market_text, parse_mode=ParseMode.HTML)


@require_group
@require_channel
async def guns_list_command(update: Update, context: ContextTypes.DEFAULT_TYPE):
    """Show weapons list"""
    guns_text = "<b>⚔️ لیست سلاح‌ها</b>\n\n"
    
    categories = {
        "cold": "❄️ سلاح‌های سرد",
        "light": "🔫 سلاح‌های سبک",
        "heavy": "💣 سلاح‌های سنگین",
        "mass": "☢️ کشتار جمعی",
        "modern": "🚀 مدرن"
    }
    
    for category, category_name in categories.items():
        guns_text += f"\n<b>{category_name}</b>\n"
        
        cat_weapons = {k: v for k, v in WeaponConfig.WEAPONS.items() 
                       if v.get("category") == category}
        
        for weapon_id, weapon_data in list(cat_weapons.items())[:3]:  # Show first 3
            guns_text += (
                f"• {weapon_data['name']} "
                f"(⚡{weapon_data['power']}) - "
                f"{weapon_data['price']:,} تومان\n"
            )
    
    guns_text += "\n\nبرای خرید: /buygun [نام]"
    
    await update.message.reply_text(guns_text, parse_mode=ParseMode.HTML)


@require_group
@require_channel
async def buy_gun_command(update: Update, context: ContextTypes.DEFAULT_TYPE):
    """Buy weapon"""
    if not context.args:
        await update.message.reply_text(
            "⚠️ استفاده صحیح: /buygun [نام]\n"
            "مثال: /buygun knife\n"
            "برای دیدن لیست: /guns"
        )
        return
    
    user_id = update.effective_user.id
    weapon_id = context.args[0].lower()
    
    if weapon_id not in WeaponConfig.WEAPONS:
        await update.message.reply_text(
            f"❌ سلاح '{weapon_id}' یافت نشد!\n"
            "برای دیدن لیست سلاح‌ها: /guns"
        )
        return
    
    weapon = WeaponConfig.WEAPONS[weapon_id]
    
    async with db_manager.session() as session:
        user_service = UserService(session)
        
        user = await user_service.get_user(user_id)
        if not user:
            await update.message.reply_text("❌ شما ثبت‌نام نکرده‌اید! /start بزنید")
            return
        
        # Check if already owned
        if not user.weapons:
            user.weapons = ["whip"]  # Default weapon
        
        if weapon_id in user.weapons:
            await update.message.reply_text(
                f"❌ شما قبلاً سلاح {weapon['name']} را خریداری کرده‌اید!"
            )
            return
        
        # Check balance
        if user.balance < weapon['price']:
            await update.message.reply_text(
                f"❌ موجودی کافی نیست!\n\n"
                f"💰 موجودی شما: {user.balance:,} تومان\n"
                f"💸 قیمت سلاح: {weapon['price']:,} تومان\n"
                f"📊 کمبود: {weapon['price'] - user.balance:,} تومان"
            )
            return
        
        # Buy weapon
        user.balance -= weapon['price']
        user.total_spent += weapon['price']
        user.weapons.append(weapon_id)
        user.current_weapon = weapon_id
        
        # Mark as modified for JSON column
        from sqlalchemy.orm.attributes import flag_modified
        flag_modified(user, "weapons")
        
        await session.commit()
        
        # Refresh
        user = await user_service.get_user(user_id, use_cache=False)
        
        await update.message.reply_text(
            f"✅ سلاح {weapon['name']} خریداری شد!\n\n"
            f"⚡ قدرت: {weapon['power']}\n"
            f"📦 دسته: {weapon['category']}\n"
            f"💰 قیمت: {weapon['price']:,} تومان\n\n"
            f"💵 موجودی باقیمانده: {user.balance:,} تومان\n"
            f"⚔️ سلاح فعلی شما: {weapon['name']}"
        )


@require_group
@require_channel
async def buy_usd_command(update: Update, context: ContextTypes.DEFAULT_TYPE):
    """Buy USD"""
    if not context.args:
        await update.message.reply_text(
            f"⚠️ استفاده صحیح: /buyusd [مقدار]\n"
            f"قیمت هر دلار: {settings.USD_PRICE:,} تومان\n"
            f"حداکثر خرید: {settings.MAX_USD} دلار"
        )
        return
    
    user_id = update.effective_user.id
    
    is_valid, amount, error = security.validate_amount(
        context.args[0],
        min_amount=1,
        max_amount=settings.MAX_USD
    )
    
    if not is_valid:
        await update.message.reply_text(f"❌ {error}")
        return
    
    total_cost = amount * settings.USD_PRICE
    
    async with db_manager.session() as session:
        user_service = UserService(session)
        
        user = await user_service.get_user(user_id)
        if not user:
            await update.message.reply_text("❌ شما ثبت‌نام نکرده‌اید! /start بزنید")
            return
        
        # Check balance
        if user.balance < total_cost:
            await update.message.reply_text(
                f"❌ موجودی کافی نیست!\n\n"
                f"💰 موجودی شما: {user.balance:,} تومان\n"
                f"💸 هزینه: {total_cost:,} تومان\n"
                f"📊 کمبود: {total_cost - user.balance:,} تومان"
            )
            return
        
        # Buy USD
        user.balance -= total_cost
        user.usd += amount
        user.total_spent += total_cost
        
        await session.commit()
        
        # Refresh
        user = await user_service.get_user(user_id, use_cache=False)
        
        await update.message.reply_text(
            f"✅ {amount} دلار خریداری شد!\n\n"
            f"💰 هزینه: {total_cost:,} تومان\n"
            f"💵 USD شما: {user.usd} $\n"
            f"💰 موجودی باقیمانده: {user.balance:,} تومان"
        )


@require_group
@require_channel
async def sell_usd_command(update: Update, context: ContextTypes.DEFAULT_TYPE):
    """Sell USD"""
    if not context.args:
        await update.message.reply_text(
            f"⚠️ استفاده صحیح: /sellusd [مقدار یا *]\n"
            f"قیمت هر دلار: {settings.USD_PRICE:,} تومان"
        )
        return
    
    user_id = update.effective_user.id
    amount_str = context.args[0]
    
    async with db_manager.session() as session:
        user_service = UserService(session)
        
        user = await user_service.get_user(user_id)
        if not user:
            await update.message.reply_text("❌ شما ثبت‌نام نکرده‌اید! /start بزنید")
            return
        
        # Determine amount
        if amount_str == "*":
            amount = user.usd
        else:
            is_valid, amount, error = security.validate_amount(amount_str, min_amount=1)
            if not is_valid:
                await update.message.reply_text(f"❌ {error}")
                return
        
        # Check USD balance
        if user.usd < amount:
            await update.message.reply_text(
                f"❌ دلار کافی ندارید!\n"
                f"💵 USD شما: {user.usd} $"
            )
            return
        
        if amount == 0:
            await update.message.reply_text("❌ شما دلار ندارید!")
            return
        
        # Sell USD
        total_gain = amount * settings.USD_PRICE
        user.usd -= amount
        user.balance += total_gain
        user.total_earned += total_gain
        
        await session.commit()
        
        # Refresh
        user = await user_service.get_user(user_id, use_cache=False)
        
        await update.message.reply_text(
            f"✅ {amount} دلار فروخته شد!\n\n"
            f"💰 دریافتی: {total_gain:,} تومان\n"
            f"💵 USD باقیمانده: {user.usd} $\n"
            f"💰 موجودی جدید: {user.balance:,} تومان"
        )
