"""
Game command handlers
"""

from telegram import Update
from telegram.ext import ContextTypes
from telegram.constants import ParseMode
from middlewares.security import require_group, require_channel, rate_limit, security
from config import settings
from models.base import db_manager
from services.user_service import UserService
import random


@require_group
@require_channel
@rate_limit("bet", max_requests=10, window=60)
async def bet_command(update: Update, context: ContextTypes.DEFAULT_TYPE):
    """Simple bet game"""
    if not context.args:
        await update.message.reply_text(
            f"⚠️ استفاده صحیح: /bet [مقدار]\n"
            f"حداقل: {settings.MIN_BET:,} تومان\n"
            f"حداکثر: {settings.MAX_BET:,} تومان"
        )
        return
    
    user_id = update.effective_user.id
    
    is_valid, amount, error = security.validate_amount(
        context.args[0],
        min_amount=settings.MIN_BET,
        max_amount=settings.MAX_BET
    )
    
    if not is_valid:
        await update.message.reply_text(f"❌ {error}")
        return
    
    async with db_manager.session() as session:
        user_service = UserService(session)
        
        user = await user_service.get_user(user_id)
        if not user:
            await update.message.reply_text("❌ شما ثبت‌نام نکرده‌اید! /start بزنید")
            return
        
        # Check balance
        if user.balance < amount:
            await update.message.reply_text(
                f"❌ موجودی کافی نیست!\n"
                f"💰 موجودی: {user.balance:,} تومان"
            )
            return
        
        # Random win/lose (48% win chance)
        win = random.random() < 0.48
        
        # Update stats
        user.total_games += 1
        
        if win:
            multiplier = settings.BET_WIN_MULTIPLIER
            if user.vip_active:
                multiplier *= settings.VIP_GAME_MULTIPLIER
            
            winnings = int(amount * multiplier)
            profit = winnings - amount
            
            # Add winnings
            user.balance += profit
            user.wins += 1
            user.win_streak += 1
            user.max_win_streak = max(user.max_win_streak, user.win_streak)
            user.total_earned += profit
            
            response = (
                f"🎉 <b>تبریک! شما بردید!</b>\n\n"
                f"💰 برد: {winnings:,} تومان\n"
                f"💎 سود خالص: {profit:,} تومان\n"
                f"📊 ضریب: {multiplier}x\n"
                f"🔥 Winning Streak: {user.win_streak}\n\n"
                f"💵 موجودی جدید: {user.balance:,} تومان"
            )
        else:
            # Lose bet
            user.balance -= amount
            user.losses += 1
            user.win_streak = 0
            user.total_spent += amount
            
            response = (
                f"😞 <b>متاسفانه باختید!</b>\n\n"
                f"💸 باخت: {amount:,} تومان\n\n"
                f"💵 موجودی باقیمانده: {user.balance:,} تومان\n"
                f"شانس بعدی بهتر خواهد بود! 💪"
            )
        
        # Update win rate
        user.win_rate = (user.wins / user.total_games) * 100 if user.total_games > 0 else 0
        
        await session.commit()
        
        await update.message.reply_text(response, parse_mode=ParseMode.HTML)


@require_group
@require_channel
@rate_limit("slot", max_requests=1, window=settings.COOLDOWN_SLOT)
async def slot_command(update: Update, context: ContextTypes.DEFAULT_TYPE):
    """Slot machine game"""
    if not context.args:
        await update.message.reply_text(
            f"⚠️ استفاده صحیح: /slot [مقدار]\n"
            f"حداقل: {settings.MIN_BET:,} تومان"
        )
        return
    
    user_id = update.effective_user.id
    
    is_valid, amount, error = security.validate_amount(
        context.args[0],
        min_amount=settings.MIN_BET
    )
    
    if not is_valid:
        await update.message.reply_text(f"❌ {error}")
        return
    
    async with db_manager.session() as session:
        user_service = UserService(session)
        
        user = await user_service.get_user(user_id)
        if not user:
            await update.message.reply_text("❌ شما ثبت‌نام نکرده‌اید! /start بزنید")
            return
        
        # Check balance
        if user.balance < amount:
            await update.message.reply_text(
                f"❌ موجودی کافی نیست!\n"
                f"💰 موجودی: {user.balance:,} تومان"
            )
            return
        
        # Send slot machine
        slot_msg = await update.message.reply_dice(emoji="🎰")
        slot_value = slot_msg.dice.value
        
        # Determine win
        jackpot_values = [1, 22, 43, 64]  # Telegram slot jackpot values
        win = slot_value in jackpot_values
        
        # Update stats
        user.total_games += 1
        
        if win:
            is_jackpot = slot_value == 64
            multiplier = settings.SLOT_JACKPOT_MULTIPLIER if is_jackpot else settings.SLOT_WIN_MULTIPLIER
            
            if user.vip_active:
                multiplier *= settings.VIP_GAME_MULTIPLIER
            
            winnings = int(amount * multiplier)
            profit = winnings - amount
            
            # Add winnings
            user.balance += profit
            user.wins += 1
            user.win_streak += 1
            user.max_win_streak = max(user.max_win_streak, user.win_streak)
            user.total_earned += profit
            
            response = (
                f"🎰 <b>{'🎉 جکپات! 🎉' if is_jackpot else '✨ برنده!'}</b>\n\n"
                f"💰 برد: {winnings:,} تومان\n"
                f"💎 سود: {profit:,} تومان\n"
                f"📊 ضریب: {multiplier}x\n"
            )
            
            if is_jackpot:
                response += f"💥 JACKPOT! 💥\n"
            
            response += f"🔥 Streak: {user.win_streak}\n\n"
            response += f"💵 موجودی: {user.balance:,} تومان"
        else:
            # Lose
            user.balance -= amount
            user.losses += 1
            user.win_streak = 0
            user.total_spent += amount
            
            response = (
                f"🎰 <b>باخت</b>\n\n"
                f"💸 {amount:,} تومان از دست رفت\n"
                f"💵 موجودی: {user.balance:,} تومان\n"
                f"⏰ تلاش بعدی: {settings.COOLDOWN_SLOT // 60} دقیقه"
            )
        
        # Update win rate
        user.win_rate = (user.wins / user.total_games) * 100 if user.total_games > 0 else 0
        
        await session.commit()
        
        await update.message.reply_text(response, parse_mode=ParseMode.HTML)


@require_group
@require_channel
@rate_limit("dice", max_requests=1, window=settings.COOLDOWN_DICE)
async def dice_command(update: Update, context: ContextTypes.DEFAULT_TYPE):
    """Dice game"""
    if not context.args:
        await update.message.reply_text(
            f"⚠️ استفاده صحیح: /dice [مقدار]\n"
            f"🎲 تاس 6 = جکپات! (ضریب {settings.DICE_JACKPOT_MULTIPLIER}x)"
        )
        return
    
    user_id = update.effective_user.id
    
    is_valid, amount, error = security.validate_amount(
        context.args[0],
        min_amount=settings.MIN_BET
    )
    
    if not is_valid:
        await update.message.reply_text(f"❌ {error}")
        return
    
    async with db_manager.session() as session:
        user_service = UserService(session)
        
        user = await user_service.get_user(user_id)
        if not user:
            await update.message.reply_text("❌ شما ثبت‌نام نکرده‌اید! /start بزنید")
            return
        
        # Check balance
        if user.balance < amount:
            await update.message.reply_text(
                f"❌ موجودی کافی نیست!\n"
                f"💰 موجودی: {user.balance:,} تومان"
            )
            return
        
        # Send dice
        dice_msg = await update.message.reply_dice(emoji="🎲")
        dice_value = dice_msg.dice.value
        
        # Update stats
        user.total_games += 1
        
        # Determine win
        if dice_value == settings.DICE_JACKPOT_NUMBER:
            # Jackpot!
            multiplier = settings.DICE_JACKPOT_MULTIPLIER
            if user.vip_active:
                multiplier *= settings.VIP_GAME_MULTIPLIER
            
            winnings = int(amount * multiplier)
            profit = winnings - amount
            
            user.balance += profit
            user.wins += 1
            user.win_streak += 1
            user.max_win_streak = max(user.max_win_streak, user.win_streak)
            user.total_earned += profit
            
            response = (
                f"🎲 <b>🎊 جکپات! عدد {dice_value}! 🎊</b>\n\n"
                f"💰 برد: {winnings:,} تومان\n"
                f"💎 سود: {profit:,} تومان\n"
                f"📊 ضریب: {multiplier}x\n"
                f"🔥 Streak: {user.win_streak}\n\n"
                f"💵 موجودی: {user.balance:,} تومان"
            )
        elif dice_value >= 4:
            # Win
            multiplier = settings.DICE_WIN_MULTIPLIER
            if user.vip_active:
                multiplier *= settings.VIP_GAME_MULTIPLIER
            
            winnings = int(amount * multiplier)
            profit = winnings - amount
            
            user.balance += profit
            user.wins += 1
            user.win_streak += 1
            user.max_win_streak = max(user.max_win_streak, user.win_streak)
            user.total_earned += profit
            
            response = (
                f"🎲 <b>✨ برنده! عدد {dice_value}</b>\n\n"
                f"💰 برد: {winnings:,} تومان\n"
                f"💎 سود: {profit:,} تومان\n"
                f"🔥 Streak: {user.win_streak}\n\n"
                f"💵 موجودی: {user.balance:,} تومان"
            )
        else:
            # Lose
            user.balance -= amount
            user.losses += 1
            user.win_streak = 0
            user.total_spent += amount
            
            response = (
                f"🎲 <b>باخت - عدد {dice_value}</b>\n\n"
                f"💸 {amount:,} تومان از دست رفت\n"
                f"💵 موجودی: {user.balance:,} تومان\n"
                f"⏰ بعدی: {settings.COOLDOWN_DICE // 60} دقیقه"
            )
        
        # Update win rate
        user.win_rate = (user.wins / user.total_games) * 100 if user.total_games > 0 else 0
        
        await session.commit()
        
        await update.message.reply_text(response, parse_mode=ParseMode.HTML)
