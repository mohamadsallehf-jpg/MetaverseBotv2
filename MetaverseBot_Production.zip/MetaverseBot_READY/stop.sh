#!/bin/bash

# ═══════════════════════════════════════════════════════
# 🛑 MetaverseBot - Stop Script
# ═══════════════════════════════════════════════════════

GREEN='\033[0;32m'
RED='\033[0;31m'
YELLOW='\033[1;33m'
NC='\033[0m'

echo -e "${YELLOW}🛑 Stopping MetaverseBot...${NC}"

# Find and kill all bot processes
if pgrep -f "python.*main.py" > /dev/null; then
    pkill -f "python.*main.py"
    sleep 2
    
    # Force kill if still running
    if pgrep -f "python.*main.py" > /dev/null; then
        pkill -9 -f "python.*main.py"
        echo -e "${RED}⚠️  Force killed bot process${NC}"
    fi
    
    echo -e "${GREEN}✅ Bot stopped${NC}"
else
    echo -e "${YELLOW}ℹ️  Bot is not running${NC}"
fi

# Clean up PID file
rm -f bot.pid

# Kill screen session if exists
if screen -ls | grep -q "metaverse"; then
    screen -X -S metaverse quit 2>/dev/null
    echo -e "${GREEN}✅ Screen session closed${NC}"
fi

echo ""
echo "To start bot again:"
echo -e "${GREEN}./start.sh${NC}"
